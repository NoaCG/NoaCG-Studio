# Font licenses

The fonts under fonts/ that came from this builder's bundled set are licensed under the
SIL Open Font License, Version 1.1. They may be bundled, embedded, redistributed and used
commercially, but not sold on their own. The complete licence and the copyright notice for
every bundled font follow.

Fonts you imported yourself are NOT covered by any of this and are governed by their own
licences — make sure you have the right to embed and distribute them before sharing a
package that contains one.

----------------------------------------------------------------------

NoaCG Studio bundles seventeen fonts. Each is licensed under the SIL Open Font
License, Version 1.1, reproduced in full below. The copyright notice for every
bundled font follows; the licence text after them applies to all seventeen.

Copyright 2020 The Inter Project Authors (https://github.com/rsms/inter)
Copyright 2020 The Space Grotesk Project Authors (https://github.com/floriankarsten/space-grotesk)
Copyright 2020 The JetBrains Mono Project Authors (https://github.com/JetBrains/JetBrainsMono)
Copyright 2018 The Manrope Project Authors (https://github.com/sharanda/manrope)
Copyright 2020 The Archivo Project Authors (https://github.com/Omnibus-Type/Archivo)
Copyright 2016 The Oswald Project Authors (https://github.com/googlefonts/OswaldFont)
Copyright © 2010 by Dharma Type.
Copyright 2017 The Playfair Display Project Authors (https://github.com/clauseggers/Playfair-Display), with Reserved Font Name "Playfair Display"
Copyright 2014 The Source Serif 4 Project Authors (https://github.com/adobe-fonts/source-serif)
Copyright © 2017 IBM Corp. with Reserved Font Name "Plex"
Copyright 2020 The Libre Franklin Project Authors (https://github.com/googlefonts/Libre-Franklin)
Copyright 2019 The Sora Project Authors (https://github.com/sora-xor/sora-font)
Copyright 2021 The Outfit Project Authors (https://github.com/Outfitio/Outfit-Fonts)
Copyright 2020 The Anton Project Authors (https://github.com/googlefonts/AntonFont.git)
Copyright 2019 The Big Shoulders Project Authors (https://github.com/xotypeco/big_shoulders)
Copyright 2020 The Saira Project Authors (https://github.com/Omnibus-Type/Saira)
Copyright 2014 The DM Sans Project Authors (https://github.com/googlefonts/dm-fonts)

Of these, "Playfair Display" and "Plex" are declared Reserved Font Names by
their copyright holders; NoaCG ships the fonts unmodified under their original
names, which the OFL permits. None of the other bundled fonts declares one.

This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at:
https://scripts.sil.org/OFL


-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font creation
efforts of academic and linguistic communities, and to provide a free and
open framework in which fonts may be shared and improved in partnership
with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded, 
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply
to any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software components as
distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to, deleting,
or substituting -- in part or in whole -- any of the components of the
Original Version, by changing formats or by porting the Font Software to a
new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed, modify,
redistribute, and sell modified and unmodified copies of the Font
Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components,
in Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the corresponding
Copyright Holder. This restriction only applies to the primary font name as
presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created
using the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.
