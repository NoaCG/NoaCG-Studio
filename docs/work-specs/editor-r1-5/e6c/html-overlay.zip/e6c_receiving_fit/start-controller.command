#!/bin/sh
# NoaCG local controller launcher. Starts the bundled relay - it serves this folder at
# http://localhost:<port>/ and opens the operator page. Ctrl+C stops it.
cd "$(dirname "$0")"
exec python3 relay.py
