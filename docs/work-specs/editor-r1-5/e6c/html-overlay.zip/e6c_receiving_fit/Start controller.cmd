@echo off
rem NoaCG local controller launcher (Windows). Starts the bundled relay - it serves this
rem folder at http://localhost:<port>/ and opens the operator page. Keep the window open
rem while operating; Ctrl+C (or closing it) stops the relay.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0relay.ps1"
pause
