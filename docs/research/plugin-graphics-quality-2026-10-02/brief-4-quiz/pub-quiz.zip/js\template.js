// Pub Quiz - SPX calls update(), play(), stop(), next().
// Fields: f0 round, f1 question number, f2 question, f3-f6 answers A-D, f7 correct letter,
// f8 answers shown (2-4), f9 timer length in seconds. Operator buttons (the machine below):
// Reveal answer, Start timer, Hide timer. » Next also reveals, for hosts without buttons.

// motionSpeed(): the template's speed knob (the NOACG_ANIM data block owns it).
function motionSpeed() {
  if (typeof NOACG_ANIM !== 'undefined' && NOACG_ANIM.speed) return NOACG_ANIM.speed;
  if (typeof animSpeed !== 'undefined' && animSpeed) return animSpeed;
  return 1;
}

// Write one field value into its element: plain text, never HTML.
function setFieldValue(el, value) {
  if (el.tagName === 'IMG') {
    if (value) { el.src = value; el.style.display = ''; }
    else { el.removeAttribute('src'); el.style.display = 'none'; }
    if (el.parentNode && el.parentNode.classList) el.parentNode.classList.toggle('has-image', !!value);
  } else {
    el.textContent = value == null ? '' : String(value);
  }
}

function fieldText(id) {
  var el = document.getElementById(id);
  return el ? String(el.textContent).trim() : '';
}

// ---- The answers ----

// clearReveal(): back to the neutral board (new question, replay).
function clearReveal() {
  var options = document.querySelectorAll('.quiz-option');
  for (var i = 0; i < options.length; i++) {
    options[i].classList.remove('quiz-correct');
    options[i].classList.remove('quiz-dim');
  }
  var root = document.querySelector('.quiz');
  if (root) root.removeAttribute('data-noacg-paint');
}

// quizRow(letter): the answer row a letter names, or null (an empty or unknown letter, or a
// row this question does not use). The empty string is rejected first: 'ABCD'.indexOf('') is 0.
function quizRow(letter) {
  var name = String(letter || '').trim().toUpperCase();
  var index = name ? 'ABCD'.indexOf(name) : -1;
  var options = document.querySelectorAll('.quiz-option');
  var row = index === -1 ? null : (options[index] || null);
  return (row && row.classList.contains('quiz-option-off')) ? null : row;
}

// applyAnswerCount(): show as many rows as this question has (f8: 2, 3 or 4), so a
// true-or-false question is a shorter board, not a board with holes.
function applyAnswerCount() {
  var options = document.querySelectorAll('.quiz-option');
  var count = parseInt(fieldText('f8'), 10);
  if (!(count >= 2 && count <= options.length)) count = options.length;
  for (var i = 0; i < options.length; i++) {
    options[i].classList.toggle('quiz-option-off', i >= count);
  }
  var root = document.querySelector('.quiz');
  if (!root) return;
  var before = root.getAttribute('data-answers');
  if (before !== null && before !== String(count)) {
    var box = document.querySelector('.quiz-box');
    if (box) { box.removeAttribute('data-stage-room'); box.style.minHeight = ''; }
  }
  root.setAttribute('data-answers', String(count));
}

function mainState() {
  if (typeof noacgMachineState !== 'function') return '';
  return (noacgMachineState().groups || {}).main || '';
}

// What the board shows, as one string: a repaint only happens when this changes, so typing
// a fix into the question never re-pops the revealed answer.
function quizPaintSig() {
  return mainState() + '|' + fieldText('f7') + '|' + fieldText('f8');
}
function markQuizPaint() {
  var root = document.querySelector('.quiz');
  if (root) root.setAttribute('data-noacg-paint', quizPaintSig());
}

// paintQuizState(): repaint the marks from the machine state plus the fields (update() and
// snap recovery both land here).
function paintQuizState() {
  var root = document.querySelector('.quiz');
  if (root && root.getAttribute('data-noacg-paint') === quizPaintSig()) return;
  if (mainState() === 'reveal') { revealAnswer(); return; }
  clearReveal();
  markQuizPaint();
}

// revealAnswer(): light the correct answer, dim the others, pop the winner, freeze the timer.
function revealAnswer() {
  var row = quizRow(fieldText('f7'));
  if (!row) return;                  // no valid correct letter: change nothing on air
  clearReveal();
  var options = document.querySelectorAll('.quiz-option');
  for (var i = 0; i < options.length; i++) {
    options[i].classList.add(options[i] === row ? 'quiz-correct' : 'quiz-dim');
  }
  freezeQuizTimer();
  gsap.fromTo(row, { scale: 1.1 }, { scale: 1, duration: 0.6 / motionSpeed(), ease: 'elastic.out(1, 0.45)' });
  markQuizPaint();
}

// ---- The timer ----
// Counts down from f9 seconds, anchored to the wall clock so a busy renderer never drifts.
var QUIZ_RING = 301.6;               // the ring's circumference (2 * pi * 48), as in the CSS
var quizTimerInterval = null;
var quizTimerDeadline = 0;
var quizTimerTotal = 30;

function quizTimerSeconds() {
  var n = parseInt(fieldText('f9'), 10);
  if (!(n > 0)) n = 30;              // blank or nonsense: the classic thirty
  return Math.min(n, 5999);
}

function formatQuizTimer(seconds) {
  if (seconds < 60) return String(seconds);
  var m = Math.floor(seconds / 60);
  var s = seconds % 60;
  return m + ':' + (s < 10 ? '0' + s : s);
}

function paintQuizTimer(msLeft) {
  var timer = document.querySelector('.quiz-timer');
  if (!timer) return;
  var seconds = Math.ceil(msLeft / 1000);
  var digits = timer.querySelector('.quiz-timer-digits');
  if (digits) digits.textContent = formatQuizTimer(seconds);
  var arc = timer.querySelector('.quiz-timer-arc');
  var used = 1 - Math.max(0, Math.min(1, msLeft / (quizTimerTotal * 1000)));
  if (arc) arc.style.strokeDashoffset = String(QUIZ_RING * used);
  timer.classList.toggle('quiz-timer-urgent', seconds > 0 && seconds <= 5);
  timer.classList.toggle('quiz-timer-done', seconds <= 0);
}

function tickQuizTimer() {
  var msLeft = Math.max(0, quizTimerDeadline - Date.now());
  paintQuizTimer(msLeft);
  if (msLeft <= 0) {
    freezeQuizTimer();
    gsap.fromTo('.quiz-timer', { rotation: -8 }, { rotation: 0, duration: 0.8 / motionSpeed(), ease: 'elastic.out(1.2, 0.25)' });
  }
}

// startQuizTimer(): the Timer running state's call. Every press starts from the top.
function startQuizTimer() {
  freezeQuizTimer();
  quizTimerTotal = quizTimerSeconds();
  quizTimerDeadline = Date.now() + quizTimerTotal * 1000;
  paintQuizTimer(quizTimerTotal * 1000);
  quizTimerInterval = setInterval(tickQuizTimer, 100);
}

// freezeQuizTimer(): stop counting and keep what is shown (time up, the reveal, Hide timer).
function freezeQuizTimer() {
  if (quizTimerInterval) { clearInterval(quizTimerInterval); quizTimerInterval = null; }
}

// resetQuizTimer(): hidden and full again, instantly (a fresh take).
function resetQuizTimer() {
  freezeQuizTimer();
  quizTimerTotal = quizTimerSeconds();
  paintQuizTimer(quizTimerTotal * 1000);
  gsap.set('.quiz-timer', { clearProps: 'opacity,scale,rotation,transform' });
}

// ---- The lifecycle ----

function update(data) {
  var fields = (typeof data === 'string') ? JSON.parse(data) : data;
  for (var key in fields) {
    var el = document.getElementById(key);
    if (el) setFieldValue(el, fields[key]);
  }
  applyAnswerCount();
  paintQuizState();
  if (!quizTimerInterval && mainState() !== 'reveal') {
    var timer = document.querySelector('.quiz-timer');
    // An idle timer shows the new length the next time it appears.
    if (timer && !timer.classList.contains('quiz-timer-done')) {
      quizTimerTotal = quizTimerSeconds();
      paintQuizTimer(quizTimerTotal * 1000);
    }
  }
  if (typeof fitStagedText === 'function') fitStagedText();
}

function play() {
  gsap.killTweensOf('*');
  clearReveal();
  resetQuizTimer();
  buildInTimeline();
}

function stop() {
  gsap.killTweensOf('*');
  freezeQuizTimer();
  buildOutTimeline();
}

// next(): SPX Continue. Step 2 is the reveal (it calls revealAnswer).
function next() {
  return (typeof revealNextStep === 'function') ? revealNextStep() : null;
}

function quizFirstPaint() {
  applyAnswerCount();
  quizTimerTotal = quizTimerSeconds();
  paintQuizTimer(quizTimerTotal * 1000);
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', quizFirstPaint);
} else {
  quizFirstPaint();
}

/* == ANIMATION (generated — the Animation panel rewrites this block) == */
// The graphic's animation as DATA. Steps play in order — the first on ▶ play(), each
// middle step on one » next() press (SPX Continue), the last on ■ stop(). Each layer's
// properties are keyframe lists on the step's local clock: { "time", "value", "ease" }.
// "reveals" names the layers that first become visible in that step; "hides" names the
// layers that leave in it; "calls" fires named template functions (a clock engine's
// startClock/stopClock) at their moment on the step's clock; "loops" makes a layer's track
// repeat (repeat -1 = forever, yoyo = breathe back and forth); "dynamics" adds MEASURED
// motion — a named builder function (defined below, outside this block) reads the DOM and
// returns the tween, which is how a marquee travels exactly one track-width no matter how
// much text the operator types. An optional "machine" adds a STATE GRAPH over the steps:
// parallel groups of states (each state's content is a timeline — the steps are the default
// path's, in order), transitions fired by operator events (noacgDispatch) or timers, and
// instant snap to any state (noacgSnap). Without it the steps ARE the machine: a linear
// walk driven by play/next/stop. The timeline UI reads and writes this block — and so can
// you: edit a number and press play.
var NOACG_ANIM = {
  "version": 2,
  "root": ".quiz",
  "speed": 1,
  "steps": [
    {
      "name": "Question",
      "duration": 1.6,
      "ease": "power3.out",
      "layers": {
        ".quiz-box": {
          "opacity": [
            {
              "time": 0,
              "value": 0
            },
            {
              "time": 0.35,
              "value": 1
            }
          ],
          "y": [
            {
              "time": 0,
              "value": 40
            },
            {
              "time": 0.5,
              "value": 0
            }
          ]
        },
        ".quiz-round": {
          "scale": [
            {
              "time": 0.2,
              "value": 0.4
            },
            {
              "time": 0.65,
              "value": 1,
              "ease": "back.out(2.2)"
            }
          ],
          "rotation": [
            {
              "time": 0.2,
              "value": -14
            },
            {
              "time": 0.65,
              "value": -2.5,
              "ease": "back.out(2.2)"
            }
          ]
        },
        ".quiz-number": {
          "scale": [
            {
              "time": 0.32,
              "value": 0.4
            },
            {
              "time": 0.77,
              "value": 1,
              "ease": "back.out(2.2)"
            }
          ],
          "rotation": [
            {
              "time": 0.32,
              "value": 12
            },
            {
              "time": 0.77,
              "value": 1.5,
              "ease": "back.out(2.2)"
            }
          ]
        },
        "#f2": {
          "yPercent": [
            {
              "time": 0.3,
              "value": 110
            },
            {
              "time": 0.85,
              "value": 0
            }
          ]
        },
        ".quiz-option-1": {
          "y": [
            {
              "time": 0.75,
              "value": 40
            },
            {
              "time": 1.2,
              "value": 0,
              "ease": "back.out(1.8)"
            }
          ],
          "opacity": [
            {
              "time": 0.75,
              "value": 0
            },
            {
              "time": 0.95,
              "value": 1
            }
          ]
        },
        ".quiz-option-2": {
          "y": [
            {
              "time": 0.85,
              "value": 40
            },
            {
              "time": 1.3,
              "value": 0,
              "ease": "back.out(1.8)"
            }
          ],
          "opacity": [
            {
              "time": 0.85,
              "value": 0
            },
            {
              "time": 1.05,
              "value": 1
            }
          ]
        },
        ".quiz-option-3": {
          "y": [
            {
              "time": 0.95,
              "value": 40
            },
            {
              "time": 1.4,
              "value": 0,
              "ease": "back.out(1.8)"
            }
          ],
          "opacity": [
            {
              "time": 0.95,
              "value": 0
            },
            {
              "time": 1.15,
              "value": 1
            }
          ]
        },
        ".quiz-option-4": {
          "y": [
            {
              "time": 1.05,
              "value": 40
            },
            {
              "time": 1.5,
              "value": 0,
              "ease": "back.out(1.8)"
            }
          ],
          "opacity": [
            {
              "time": 1.05,
              "value": 0
            },
            {
              "time": 1.25,
              "value": 1
            }
          ]
        }
      }
    },
    {
      "name": "Reveal",
      "duration": 0.6,
      "ease": "power3.out",
      "calls": [
        {
          "time": 0,
          "call": "revealAnswer"
        }
      ],
      "layers": {}
    },
    {
      "name": "Out",
      "duration": 0.4,
      "ease": "power2.in",
      "layers": {
        ".quiz-box": {
          "opacity": [
            {
              "time": 0,
              "value": 1
            },
            {
              "time": 0.4,
              "value": 0
            }
          ],
          "y": [
            {
              "time": 0,
              "value": 0
            },
            {
              "time": 0.4,
              "value": -30
            }
          ]
        }
      }
    }
  ],
  "machine": {
    "groups": [
      {
        "id": "main",
        "initial": "off",
        "defaultPath": [
          "question",
          "reveal",
          "out"
        ],
        "states": [
          {
            "id": "off",
            "name": "Off"
          },
          {
            "id": "question",
            "name": "Question"
          },
          {
            "id": "reveal",
            "name": "Answer revealed"
          },
          {
            "id": "out",
            "name": "Out"
          }
        ],
        "transitions": [
          {
            "from": "question",
            "to": "reveal",
            "trigger": "operator",
            "event": "judge"
          }
        ]
      },
      {
        "id": "timer",
        "initial": "hidden",
        "states": [
          {
            "id": "hidden",
            "name": "Timer hidden",
            "timeline": {
              "name": "Hide timer",
              "duration": 0.3,
              "ease": "power2.in",
              "calls": [
                {
                  "time": 0,
                  "call": "freezeQuizTimer"
                }
              ],
              "layers": {
                ".quiz-timer": {
                  "opacity": [
                    {
                      "time": 0,
                      "value": 1
                    },
                    {
                      "time": 0.3,
                      "value": 0
                    }
                  ],
                  "scale": [
                    {
                      "time": 0,
                      "value": 1
                    },
                    {
                      "time": 0.3,
                      "value": 0.4
                    }
                  ]
                }
              }
            }
          },
          {
            "id": "running",
            "name": "Timer running",
            "timeline": {
              "name": "Start timer",
              "duration": 0.5,
              "ease": "power3.out",
              "calls": [
                {
                  "time": 0,
                  "call": "startQuizTimer"
                }
              ],
              "layers": {
                ".quiz-timer": {
                  "opacity": [
                    {
                      "time": 0,
                      "value": 0
                    },
                    {
                      "time": 0.15,
                      "value": 1
                    }
                  ],
                  "scale": [
                    {
                      "time": 0,
                      "value": 0.4
                    },
                    {
                      "time": 0.5,
                      "value": 1,
                      "ease": "back.out(2.4)"
                    }
                  ]
                }
              }
            }
          }
        ],
        "transitions": [
          {
            "from": "hidden",
            "to": "running",
            "trigger": "operator",
            "event": "startTimer"
          },
          {
            "from": "running",
            "to": "running",
            "trigger": "operator",
            "event": "startTimer"
          },
          {
            "from": "running",
            "to": "hidden",
            "trigger": "operator",
            "event": "hideTimer"
          }
        ]
      }
    ],
    "controls": [
      {
        "event": "judge",
        "label": "Reveal answer",
        "order": 1,
        "section": "Answer",
        "payload": [
          "f7"
        ]
      },
      {
        "event": "startTimer",
        "label": "Start timer",
        "order": 2,
        "section": "Timer"
      },
      {
        "event": "hideTimer",
        "label": "Hide timer",
        "order": 3,
        "section": "Timer"
      }
    ]
  }
};

// ---- The interpreter (the same in every template — edit the DATA above instead) ----
// Steps play on the operator's cues: steps[0] on play(), each middle step on one next()
// press, the last step on stop(). Keyframe times sit on the step's local clock and are
// divided by the speed knob. A keyframe's ease is the ease INTO it (default: the step's).
// When the data carries a "machine", the same cues drive its default path, and the state
// engine below adds operator events (noacgDispatch), timers, and instant snap (noacgSnap).
// ---- Eases (shared with the editor, which samples, splits and reverses keys with this code) ----
// Capability: shared-ease-v2. noacgEase(text) returns the curve E(p) of an ease string, or null
// when the string is outside this grammar; the interpreter then hands the string to GSAP as it
// always did. A recognized ease reaches GSAP as this function, never as a string it could replace
// with its default.
//   none | linear, power0-4, quad, cubic, quart, quint, strong, sine, expo, circ, bounce, back(s)
//   or elastic(a, p), each with .in, .out or .inOut (bare means .out) | steps(n) | steps(n, true)
//   | cubic-bezier(x1, y1, x2, y2) with x1 and x2 in 0..1
//   | slice(ease, a, b): that ease between a and b, rescaled to run from 0 to 1
//   | hold: keep the departing key's value, then jump to the arriving key's (a Hold keyframe)
//   | jump: jump to the arriving key's value at once, then keep it (a Hold played backwards).
// Named curves repeat GSAP 3.15's formulas in its operation order, so they match it exactly.
var noacgEaseCache = {};
// GSAP rounds timeline times to 1e-7 s, so at a key's exact time the segment arriving there can
// read 0.9999987 rather than 1. A hold jumps in the last 1e-5 of its segment, which that rounding
// still reaches for any segment of 10 ms or more, and a jump mirrors it at the start.
var NOACG_EASE_EDGE = 1e-5;
var NOACG_EASE_POWER = { linear: 1, power0: 1, quad: 2, power1: 2, cubic: 3, power2: 3, quart: 4, power3: 4, quint: 5, power4: 5, strong: 5 };
var NOACG_EASE_SHAPED = { sine: 1, expo: 1, circ: 1, bounce: 1, back: 1, elastic: 1 };
var NOACG_EASE_TWO_PI = 2 * Math.PI;
function noacgEaseHas(map, name) { return Object.prototype.hasOwnProperty.call(map, name); }
function noacgEaseNumber(text) {
  return /^\s*[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?\s*$/i.test(text) ? Number(text) : NaN;
}
// An argument list split on its top-level commas: a slice carries a whole ease inside it.
function noacgEaseArgs(text) {
  var parts = [], depth = 0, from = 0;
  for (var i = 0; i < text.length; i++) {
    var c = text.charAt(i);
    if (c === '(') depth++;
    else if (c === ')') depth--;
    else if (c === ',' && depth === 0) { parts.push(text.slice(from, i)); from = i + 1; }
  }
  parts.push(text.slice(from));
  return parts;
}

// Describe an ease string, or return null. The text itself is never rewritten.
function noacgEaseParse(text) {
  if (typeof text !== 'string') return null;
  if (text === 'none') return { kind: 'none', text: text };
  var m = /^([a-z][a-z0-9]*(?:-[a-z]+)?)(?:\.(in|out|inOut))?(?:\((.*)\))?$/.exec(text);
  if (!m) return null;
  var name = m[1], side = m[2], called = m[3] !== undefined, args = called ? noacgEaseArgs(m[3]) : [], values = [], i;
  for (i = 0; i < args.length; i++) values.push(noacgEaseNumber(args[i]));
  if (noacgEaseHas(NOACG_EASE_POWER, name) || noacgEaseHas(NOACG_EASE_SHAPED, name)) {
    var most = name === 'back' ? 1 : name === 'elastic' ? 2 : 0;
    if (called && (args.length > most || values.some(function (v) { return !isFinite(v); }))) return null;
    return { kind: 'family', text: text, name: name, side: side || 'out', args: called ? values : [], argText: called ? '(' + m[3] + ')' : '' };
  }
  if ((name === 'hold' || name === 'jump') && !side && !called) return { kind: name, text: text };
  if (side || !called) return null;
  if (name === 'steps' && args.length <= 2) {
    var count = values[0];
    if (!(count >= 1 && count === Math.floor(count))) return null;
    if (args.length === 2 && args[1].replace(/^\s+|\s+$/g, '') !== 'true') return null;
    return { kind: 'steps', text: text, count: count, start: args.length === 2 };
  }
  if (name === 'cubic-bezier' && args.length === 4) {
    if (values.some(function (v) { return !isFinite(v); })) return null;
    // x1 and x2 inside 0..1 keep time monotonic, so every moment has one value.
    if (!(values[0] >= 0 && values[0] <= 1 && values[2] >= 0 && values[2] <= 1)) return null;
    return { kind: 'bezier', text: text, x1: values[0], y1: values[1], x2: values[2], y2: values[3] };
  }
  if (name === 'slice' && args.length === 3) {
    var base = noacgEaseParse(args[0]), from = values[1], to = values[2];
    // A slice rescales a moving part; a step, a hold or a jump has only flat parts and one instant.
    if (!base || base.kind === 'slice' || base.kind === 'steps' || base.kind === 'hold' || base.kind === 'jump' || !(from >= 0 && from < to && to <= 1)) return null;
    var curve = noacgEaseCurve(base), low = curve(from), high = curve(to);
    // Equal ends leave nothing to rescale: no slice can carry motion between them.
    if (!isFinite(low) || !isFinite(high) || low === high) return null;
    return { kind: 'slice', text: text, base: base, from: from, to: to };
  }
  return null;
}

function noacgEaseBounceOut(t) {
  if (t < 1 / 2.75) return 7.5625 * t * t;
  if (t < 0.7272727272727273) return 7.5625 * Math.pow(t - 1.5 / 2.75, 2) + 0.75;
  if (t < 0.9090909090909092) { var u = t - 2.25 / 2.75; return 7.5625 * u * u + 0.9375; }
  return 7.5625 * Math.pow(t - 2.625 / 2.75, 2) + 0.984375;
}
// CSS cubic-bezier: solve x(s) = p (Newton, then bisection), then read y(s).
function noacgEaseBezier(x1, y1, x2, y2) {
  function at(a, b, s) { return ((1 - 3 * b + 3 * a) * s + 3 * b - 6 * a) * s * s + 3 * a * s; }
  function slope(a, b, s) { return 3 * (1 - 3 * b + 3 * a) * s * s + 2 * (3 * b - 6 * a) * s + 3 * a; }
  return function (p) {
    if (p <= 0) return 0;
    if (p >= 1) return 1;
    var s = p, i, x, d;
    for (i = 0; i < 8; i++) {
      x = at(x1, x2, s) - p;
      if (Math.abs(x) < 1e-12) return at(y1, y2, s);
      d = slope(x1, x2, s);
      if (Math.abs(d) < 1e-9) break;
      s -= x / d;
      if (s < 0 || s > 1) break;
    }
    var low = 0, high = 1;
    for (s = p, i = 0; i < 100; i++) {
      x = at(x1, x2, s);
      if (Math.abs(x - p) < 1e-12) break;
      if (x < p) low = s; else high = s;
      s = (low + high) / 2;
    }
    return at(y1, y2, s);
  };
}

// The curve of a parsed ease. Named families follow GSAP: out(p) = 1 - in(1 - p) unless GSAP
// defines out directly (power, back, elastic, bounce), and inOut joins two halves at 0.5.
function noacgEaseCurve(e) {
  if (e.kind === 'none') return function (p) { return p; };
  if (e.kind === 'hold') return function (p) { return p >= 1 - NOACG_EASE_EDGE ? 1 : 0; };
  if (e.kind === 'jump') return function (p) { return p > NOACG_EASE_EDGE ? 1 : 0; };
  if (e.kind === 'bezier') return noacgEaseBezier(e.x1, e.y1, e.x2, e.y2);
  if (e.kind === 'steps') {
    var share = 1 / e.count, levels = e.count + (e.start ? 0 : 1), lift = e.start ? 1 : 0;
    return function (p) { var c = p > 0.99999999 ? 0.99999999 : p < 0 ? 0 : p; return ((levels * c | 0) + lift) * share; };
  }
  if (e.kind === 'slice') {
    var base = noacgEaseCurve(e.base), a = e.from, b = e.to, low = base(a), span = base(b) - low;
    return function (p) { return p === 0 ? 0 : p === 1 ? 1 : (base(a + (b - a) * p) - low) / span; };
  }
  var name = e.name, easeIn, easeOut, easeInOut;
  if (noacgEaseHas(NOACG_EASE_POWER, name)) {
    var r = NOACG_EASE_POWER[name];
    easeIn = r === 1 ? function (p) { return p; } : function (p) { return Math.pow(p, r); };
    easeOut = function (p) { return 1 - Math.pow(1 - p, r); };
    easeInOut = function (p) { return p < 0.5 ? Math.pow(2 * p, r) / 2 : 1 - Math.pow(2 * (1 - p), r) / 2; };
  } else if (name === 'back' || name === 'elastic') {
    if (name === 'back') {
      var s = e.args.length ? e.args[0] : 1.70158;
      easeOut = function (p) { if (!p) return 0; var u = p - 1; return u * u * ((s + 1) * u + s) + 1; };
    } else {
      var type = e.side === 'inOut' ? undefined : e.side, amplitude = e.args[0], period = e.args[1];
      var amp = amplitude >= 1 ? amplitude : 1;
      var per = (period || (type ? 0.3 : 0.45)) / (amplitude < 1 ? amplitude : 1);
      var shift = per / NOACG_EASE_TWO_PI * (Math.asin(1 / amp) || 0), w = NOACG_EASE_TWO_PI / per;
      easeOut = function (p) { return p === 1 ? 1 : amp * Math.pow(2, -10 * p) * Math.sin((p - shift) * w) + 1; };
    }
    easeIn = function (p) { return 1 - easeOut(1 - p); };
    easeInOut = function (p) { return p < 0.5 ? (1 - easeOut(1 - 2 * p)) / 2 : 0.5 + easeOut(2 * (p - 0.5)) / 2; };
  } else {
    if (name === 'bounce') {
      easeOut = noacgEaseBounceOut;
      easeIn = function (p) { return 1 - noacgEaseBounceOut(1 - p); };
    } else {
      easeIn = name === 'sine' ? function (p) { return p === 1 ? 1 : 1 - Math.cos(p * (NOACG_EASE_TWO_PI / 4)); }
        : name === 'expo' ? function (p) { return Math.pow(2, 10 * (p - 1)) * p + p * p * p * p * p * p * (1 - p); }
        : function (p) { return -(Math.sqrt(1 - p * p) - 1); };
      easeOut = function (p) { return 1 - easeIn(1 - p); };
    }
    easeInOut = function (p) { return p < 0.5 ? easeIn(p * 2) / 2 : 1 - easeIn((1 - p) * 2) / 2; };
  }
  return e.side === 'in' ? easeIn : e.side === 'inOut' ? easeInOut : easeOut;
}

// The curve for an ease string, parsed once per string.
function noacgEase(text) {
  var key = '~' + text;
  if (!noacgEaseHas(noacgEaseCache, key)) {
    var parsed = noacgEaseParse(text);
    noacgEaseCache[key] = parsed ? noacgEaseCurve(parsed) : null;
  }
  return noacgEaseCache[key];
}
// What the interpreter hands GSAP: the shared curve when recognized, else the string as before.
function noacgEaseOf(text) { return noacgEase(text) || text; }

// A dynamics builder takes the step's ease as a string (its API). It gets the shared curve only
// when GSAP cannot read a string the shared grammar recognizes, so nothing it builds defaults.
function noacgEaseForBuilder(text) {
  return typeof gsap.parseEase(text) === 'function' ? text : noacgEaseOf(text);
}

var noacgStepsPlayed = 0; // how many steps have run (play() = the first)
var noacgLiveTimeline = null;
var noacgOutTimeline = null;

// Capability: live-pose-out-v1. Capture before killing or applying any first key.
function noacgOutActive() { return !!noacgOutTimeline; }
function noacgRememberEntrance(tl) {
  if (noacgOutTimeline) noacgOutTimeline.kill();
  noacgOutTimeline = null;
  noacgLiveTimeline = tl;
  return tl;
}

// Exit motion uses object targets so an older stop() scaffold's killTweensOf('*')
// cannot destroy a repeated Out. The property setter also runs during silent seek.
function noacgExitProxy(element, prop, value) {
  var proxy = {};
  Object.defineProperty(proxy, 'value', {
    get: function () { return value; },
    set: function (next) { value = next; var vars = {}; vars[prop] = next; gsap.set(element, vars); }
  });
  return proxy;
}
function noacgExitVisible(element, selector) {
  for (var el = element; el; el = el.parentElement) {
    var style = getComputedStyle(el);
    if (style.visibility === 'hidden' || style.display === 'none') return false;
  }
  for (var s = noacgStepsPlayed; s < NOACG_ANIM.steps.length - 1; s++) {
    if ((NOACG_ANIM.steps[s].reveals || []).indexOf(selector) >= 0) return false;
  }
  return true;
}
// An interrupted exit stretches its last ease over the whole way from the live pose. A slice is
// part of a curve rescaled to its own ends, so stretched that far it can swing well past both;
// the interruption plays the whole curve it was cut from instead.
function noacgWholeEase(text) {
  var parsed = noacgEaseParse(text);
  return parsed && parsed.kind === 'slice' ? parsed.base.text : text;
}
function noacgBuildExit(step, interrupted, silent, early) {
  var speed = NOACG_ANIM.speed || 1;
  // Out's first "carried" seconds finish the motion of the cue before it, which Set Out cut
  // mid-motion; the exit proper starts after them. Out pressed at an earlier step never reached
  // that cue, so it skips them and the exit starts at the press.
  var skip = early ? step.carried || 0 : 0;
  var at = function (time) { return Math.max(0, time - skip); };
  var entries = [];
  Object.keys(step.layers).forEach(function (selector) {
    document.querySelectorAll(selector).forEach(function (element) {
      if (!noacgExitVisible(element, selector)) return;
      Object.keys(step.layers[selector]).forEach(function (prop) {
        var keys = step.layers[selector][prop];
        if (keys.length) entries.push({ element: element, prop: prop, keys: keys, live: gsap.getProperty(element, prop) });
      });
    });
  });
  if (noacgLiveTimeline) noacgLiveTimeline.kill();
  gsap.killTweensOf('*');
  var effects = Object.assign({}, step, { duration: at(step.duration), layers: {}, spans: undefined, hides: undefined, loops: undefined });
  if (silent) { effects.calls = []; effects.dynamics = []; }
  var tl = buildStepTimeline(effects);
  // Gate only already-visible layers. Object targets survive legacy repeated stop(). An
  // interrupted exit keeps each layer's visibility until it ends and then takes the Out's end
  // state, which also reaches a layer outside the root that the root's own hide cannot.
  Object.keys(step.spans || {}).forEach(function (selector) {
    document.querySelectorAll(selector).forEach(function (element) {
      if (!noacgExitVisible(element, selector)) return;
      var spans = step.spans[selector], times = [interrupted ? step.duration : 0];
      var proxy = noacgExitProxy(element, 'visibility', getComputedStyle(element).visibility);
      if (!interrupted) spans.forEach(function (span) { times.push(span.start, span.end); });
      times.sort(function (a, b) { return a - b; }).forEach(function (time) {
        tl.set(proxy, { value: noacgSpanVisible(spans, time, step.duration) ? 'visible' : 'hidden' }, at(time) / speed);
      });
    });
  });
  (step.hides || []).forEach(function (selector) {
    if (step.spans && step.spans[selector] !== undefined) return;
    document.querySelectorAll(selector).forEach(function (element) {
      tl.set(noacgExitProxy(element, 'opacity', gsap.getProperty(element, 'opacity')), { value: 0 }, at(step.duration) / speed);
    });
  });
  entries.forEach(function (entry) {
    var keys = entry.keys;
    var proxy = noacgExitProxy(entry.element, entry.prop, entry.live);
    var last = keys[keys.length - 1], first = 0;
    // Skipping carried time, the track's exit starts at its first key after it: the key that ends
    // the carried motion there only starts the exit when the exit moves on from it at once.
    if (skip) {
      while (first < keys.length - 1 && keys[first].time < skip) first++;
      if (keys[first].time === skip && first > 0 && first < keys.length - 1 && keys[first - 1].value !== keys[first].value && keys[first + 1].value === keys[first].value) first++;
    }
    if (interrupted && keys.length > 1 && last.time > keys[first].time) {
      var ease = noacgWholeEase(last.ease || step.ease), shape = noacgEaseParse(ease);
      // A final jump (a Hold played backwards) happens where its own segment starts, as it does
      // when Out is not interrupted; until then the live value holds.
      var from = at(shape && shape.kind === 'jump' ? keys[keys.length - 2].time : keys[first].time);
      tl.to(proxy, { value: last.value, duration: (at(last.time) - from) / speed, ease: noacgEaseOf(ease) }, from / speed);
    } else if (early) {
      // A one-key or zero-time track has no span to leave on. From an earlier step its value may be
      // a pose the viewer never saw, so it holds the live value and takes its own as the exit ends.
      // So does a track whose motion is all carried.
      tl.set(proxy, { value: last.value }, at(step.duration) / speed);
    } else {
      tl.set(proxy, { value: keys[0].value }, 0);
      for (var k = 1; k < keys.length; k++) {
        tl.to(proxy, { value: keys[k].value, duration: (keys[k].time - keys[k - 1].time) / speed,
          ease: noacgEaseOf(keys[k].ease || step.ease) }, keys[k - 1].time / speed);
      }
    }
  });
  return tl;
}

// Visibility is independent of opacity. At an arriving hold keep the interval's
// endpoint; a new cue's timeline owns its departing zero. Disjoint sets seek both ways.
function noacgSpanVisible(spans, time, duration) {
  return spans.some(function (span) {
    return time >= span.start && (time < span.end || time === duration && span.end === duration);
  });
}

// Build one step's GSAP timeline from its keyframe data. The first keyframe of a track
// is the starting state, applied instantly at the step start (it "holds backward" —
// the familiar keyframe convention); later keyframes tween from the previous one.
// Takes a step index — or a state's inline timeline object, which plays the same way.
function buildStepTimeline(index) {
  var step = typeof index === 'number' ? NOACG_ANIM.steps[index] : index;
  var speed = NOACG_ANIM.speed || 1;
  var tl = gsap.timeline();
  Object.keys(step.spans || {}).forEach(function (selector) {
    var spans = step.spans[selector];
    var times = [0];
    spans.forEach(function (span) { times.push(span.start, span.end); });
    times.sort(function (a, b) { return a - b; }).forEach(function (time) {
      tl.set(selector, { visibility: noacgSpanVisible(spans, time, step.duration) ? 'visible' : 'hidden' }, time / speed);
    });
  });
  Object.keys(step.layers).forEach(function (selector) {
    var tracks = step.layers[selector];
    Object.keys(tracks).forEach(function (prop) {
      var kfs = tracks[prop];
      if (!kfs.length) return;
      var loop = step.loops && step.loops[selector] && step.loops[selector][prop];
      if (loop) {
        // A looping track plays in its own repeating sub-timeline (a breathing pulse, a
        // marquee-style cycle): the sub-timeline's length is the loop period, and it is
        // added to the step at the track's first keyframe time. repeat -1 = forever.
        var sub = gsap.timeline({
          repeat: loop.repeat,
          yoyo: !!loop.yoyo,
          repeatDelay: (loop.repeatDelay || 0) / speed
        });
        var s0 = {};
        s0[prop] = kfs[0].value;
        sub.set(selector, s0, 0);
        for (var j = 1; j < kfs.length; j++) {
          var lv = {};
          lv[prop] = kfs[j].value;
          lv.duration = (kfs[j].time - kfs[j - 1].time) / speed;
          lv.ease = noacgEaseOf(kfs[j].ease || step.ease);
          sub.to(selector, lv, (kfs[j - 1].time - kfs[0].time) / speed);
        }
        tl.add(sub, kfs[0].time / speed);
        return;
      }
      var start = {};
      start[prop] = kfs[0].value;
      tl.set(selector, start, 0);
      for (var i = 1; i < kfs.length; i++) {
        var vars = {};
        vars[prop] = kfs[i].value;
        vars.duration = (kfs[i].time - kfs[i - 1].time) / speed;
        vars.ease = noacgEaseOf(kfs[i].ease || step.ease);
        tl.to(selector, vars, kfs[i - 1].time / speed);
      }
    });
  });
  // Layers that LEAVE in this step: hide them at the step's end. Their keyframes above
  // animate the exit; this makes the departure definitive (the twin of reveals' pre-hide),
  // so a layer can leave before the final Out. Replay re-arms it (resetGraphic clears the
  // inline props, then step 0 shows it again).
  (step.hides || []).forEach(function (selector) {
    if (step.spans && step.spans[selector] !== undefined) return;
    tl.set(selector, { opacity: 0 }, step.duration / speed);
  });
  // Step calls: named template functions fire at their moment on the step's clock (the
  // clock engine's startClock/stopClock — the timeline never owns that logic). Resolved by
  // name at fire time so hand edits and load order never matter; a missing function is a
  // silent no-op. Scrub/settle inherit GSAP's own callback suppression (progress(1, true)),
  // so a settled state never re-fires the clock.
  for (var c = 0; c < (step.calls || []).length; c++) {
    (function (name, at) {
      tl.call(function () {
        var fn = window[name];
        if (typeof fn === 'function') fn();
      }, null, at / speed);
    })(step.calls[c].call, step.calls[c].time);
  }
  // Dynamic motion: a design-owned builder MEASURES the DOM and returns a GSAP
  // tween/timeline (a marquee's width-derived travel, a credits roll, one flip per item).
  // The keyframe data above cannot describe motion whose magnitude depends on the
  // operator's content, so it names a builder instead — the logic stays readable JS,
  // outside this region, where you can edit it. Resolved by name at build time (no eval);
  // a missing builder is a silent no-op.
  //
  // THE LEAD, and why a builder may want it (templates/infographics/igMotion.ts states the rule
  // in full under THE ZERO RULE). A dynamic's time is a HEAD START: the step reveals the graphic
  // at 0 and the measured motion begins a few tenths later, once the panel has settled. A
  // builder that only MOVES things is happy to be added at that offset. A builder that owns a
  // READOUT is not: the operator's data is written before the graphic is taken (SPX, CasparCG
  // and the playout dashboard all call update() and then play()), so a figure emptied to zero
  // when its own count begins is on screen showing the real number until then, and then snaps
  // back to zero to count up to it. So the head start is handed over as opts.lead as well, and
  // a builder that positions its own contents from it says so by marking the timeline it
  // returns - that one is added at 0, where its opening zero lands on the step's first frame.
  // Everything else is added exactly where it always was.
  for (var d = 0; d < (step.dynamics || []).length; d++) {
    (function (name, target, at) {
      var build = window[name];
      if (typeof build !== 'function') return;
      var lead = (at || 0) / speed;
      var segment = build(target, { speed: speed, ease: noacgEaseForBuilder(step.ease), lead: lead });
      if (segment) tl.add(segment, segment.noacgLeadApplied ? 0 : lead);
    })(step.dynamics[d].build, step.dynamics[d].target, step.dynamics[d].time);
  }
  // Pad to the step's full duration — settled air at the end is part of the step.
  // (A dynamic segment may run LONGER than this: its length is measured at play time, so
  // the step's authored duration is a floor, not a cap.)
  tl.set({ noacgPad: 0 }, { noacgPad: 1 }, step.duration / speed);
  return tl;
}

// Layers revealed by a later step start hidden: pre-apply their reveal step's first
// keyframe values (their "from" state; plain opacity 0 when the step gives them no
// keyframes). Runs inside play()'s timeline, so every replay re-arms the reveals.
function noacgApplyReveals(tl) {
  var steps = NOACG_ANIM.steps;
  for (var s = 1; s < steps.length - 1; s++) {
    (steps[s].reveals || []).forEach(function (selector) {
      var tracks = steps[s].layers[selector];
      if (steps[0].spans && steps[0].spans[selector] !== undefined) return;
      var hidden = false;
      if (tracks) Object.keys(tracks).forEach(function (prop) {
        if (!tracks[prop].length) return;
        var vars = {};
        vars[prop] = tracks[prop][0].value;
        tl.set(selector, vars, 0);
        // transformOrigin is static pivot chrome, not entrance motion — it doesn't pre-hide.
        if (prop !== 'transformOrigin') hidden = true;
      });
      if (!hidden) tl.set(selector, { opacity: 0 }, 0);
    });
  }
}

// noacgPaintFirstFrame(tl): put the timeline's opening values in the DOM NOW, not on the next
// animation frame. Returns the timeline, so a builder can end on it.
//
// Every opening value this interpreter writes is a set() ON the timeline (buildStepTimeline
// above, the root reveal and the reveal pre-arm below), and a GSAP timeline renders nothing
// until the ticker next runs. The operator's cue - play(), next(), a dispatched event - is ONE
// synchronous task, so the browser paints once between that task ending and the first tick. What
// it paints is the graphic exactly as it already was.
//
// Off air that paints nothing, because the root sits at opacity 0. ON AIR it paints everything,
// and a graphic is on air for most of these cues: the studio canvas and the Rehearse panel both
// settle a graphic and then take it, a dashboard, SPX or CasparCG take of a graphic that is
// still up re-enters from a visible state, and EVERY next() and every event transition is by
// definition a cue on a graphic the viewer is already watching.
//
// Measured 2026-09-03 on a settled ig05 "Rising Total": play() returned with #f0 still reading
// its real 124,213 at opacity 1, and the entrance's zero landed 14 ms later. That is the owner's
// 2026-08-28 walk report exactly - the full figure on take, a snap to zero, then the count - and
// it is the frame the ZERO RULE (templates/infographics/igMotion.ts) cannot reach, because the
// zero rule moved the emptying onto the entrance's first frame and the first frame was itself a
// frame late. Eleven readouts across ten designs painted their settled figure that way.
//
// This writes precisely what the next tick would have written, with events suppressed, so timing
// and content are unchanged - only the moment the opening values reach the DOM moves, by one
// frame, onto the cue itself. Callbacks are NOT fired here (a step call at time 0 still runs on
// the first real tick, which is what keeps a clock engine's start unaffected).
function noacgPaintFirstFrame(tl) {
  if (tl) tl.render(0, true, true);
  return tl;
}

// The entrance recipe: step 0, the root reveal, and the reveal pre-arm — shared by play(),
// the machine's entrance, and snap's pose composition, so they can never drift apart.
function noacgEntranceTimeline() {
  var tl = buildStepTimeline(0);
  tl.set(NOACG_ANIM.root, { opacity: 1 }, 0); // reveal the (CSS-hidden) graphic
  noacgApplyReveals(tl);
  return noacgRememberEntrance(noacgPaintFirstFrame(tl));
}

// The exit recipe — the Out step plus the off-air cleanup, shared the same way.
function noacgExitTimeline(interrupted, silent) {
  if (!silent && noacgOutTimeline) return noacgOutTimeline;
  var steps = NOACG_ANIM.steps;
  var step = steps.length > 1 ? steps[steps.length - 1] : { duration: 0, ease: 'none', layers: {} };
  if (interrupted === undefined) interrupted = !!noacgLiveTimeline && noacgLiveTimeline.time() < noacgLiveTimeline.duration();
  // Out from an earlier step, with a Next cue not yet played, leaves from what is on screen as an
  // interrupted Out does: never through the last step's pose or motion the viewer has not seen.
  // A machine's states are an authored graph, not a linear reveal, so it keeps its own exit.
  var early = !NOACG_ANIM.machine && noacgStepsPlayed > 0 && noacgStepsPlayed < steps.length - 1;
  if (early) interrupted = true;
  var tl = noacgBuildExit(step, interrupted, silent, early);
  // Press-revealed layers OUTSIDE the root miss its hide — fade them with the exit
  // (unless the Out step animates them itself). Containment is checked live. The exit starts
  // after the motion Out carries, which Out pressed at an earlier step skips; motion carried
  // on such a layer is not the exit animating it.
  var root = document.querySelector(NOACG_ANIM.root), carried = step.carried || 0;
  var exits = function (selector) {
    var tracks = step.layers[selector] || {};
    return Object.keys(tracks).some(function (prop) { return tracks[prop].some(function (key) { return key.time > carried; }); });
  };
  for (var s = 1; s < steps.length - 1; s++) {
    (steps[s].reveals || []).forEach(function (selector) {
      var el = document.querySelector(selector);
      if (el && root && !root.contains(el) && !exits(selector)) {
        tl.to(noacgExitProxy(el, 'opacity', gsap.getProperty(el, 'opacity')), { value: 0, duration: Math.min(0.3, step.duration - carried) / (NOACG_ANIM.speed || 1) }, (early ? 0 : carried) / (NOACG_ANIM.speed || 1));
      }
    });
  }
  if (root) tl.set(noacgExitProxy(root, 'opacity', gsap.getProperty(root, 'opacity')), { value: 0 }); // fully hidden; ready to play again
  if (!silent) noacgOutTimeline = tl;
  return noacgPaintFirstFrame(tl);
}

// buildInTimeline(): the entrance. Called by play(). With a machine, play() is the built-in
// reset-and-enter event; without one, the classic linear walk (byte-for-byte).
function buildInTimeline() {
  if (noacgOutTimeline) noacgOutTimeline.kill();
  noacgOutTimeline = null;
  noacgLiveTimeline = null;
  if (NOACG_ANIM.machine) return noacgMachinePlay();
  noacgStepsPlayed = 1;
  var tl = noacgEntranceTimeline();
  noacgTrackPath(); // pointer bookkeeping only — playback is untouched
  return tl;
}

// revealNextStep(): one default-path advance per next() press; null when only Out remains, and
// once Out has started, until the next play(): a Next cue never plays on the way out.
function revealNextStep() {
  if (NOACG_ANIM.machine) return noacgMachineNext();
  if (noacgOutTimeline || noacgStepsPlayed >= NOACG_ANIM.steps.length - 1) return null;
  // Paint the step's opening values on the press, not a frame after it: next() is pressed on a
  // graphic the viewer is already watching, so a frame of the previous step's end pose is the
  // most visible case of all (noacgPaintFirstFrame above).
  var tl = noacgPaintFirstFrame(buildStepTimeline(noacgStepsPlayed++));
  noacgLiveTimeline = tl;
  noacgTrackPath();
  return tl;
}

// buildOutTimeline(): the exit. Called by stop() — the built-in event that is legal from
// EVERY state (an operator can always take the graphic off air).
function buildOutTimeline() {
  if (noacgOutTimeline) return noacgOutTimeline;
  if (NOACG_ANIM.machine) return noacgMachineStop();
  var tl = noacgExitTimeline();
  noacgResetPointers();
  return tl;
}

// ---- The state machine (docs/STATE_MACHINE_SCHEMA.md) ----
// States are what the graphic looks like (each one's content is a timeline); transitions are
// arrows fired by operator events or timers; parallel groups run independent small graphs.
// When NOACG_ANIM.machine is absent, the implicit ONE-GROUP linear machine is derived from
// the step chain (mirrors blocks/animMachine.ts deriveMachine — keep them in agreement) and
// playback still runs the classic statements above; the derived machine exists so
// noacgDispatch / noacgSnap / noacgMachineState answer for every template.
var noacgMachine = (function () {
  if (NOACG_ANIM.machine) return NOACG_ANIM.machine;
  function slug(name) {
    var s = String(name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    return s || 'state';
  }
  var used = { off: true };
  var states = [{ id: 'off', name: 'Off' }];
  var path = [];
  for (var i = 0; i < NOACG_ANIM.steps.length; i++) {
    var stepName = NOACG_ANIM.steps[i].name;
    var id = slug(stepName);
    for (var n = 2; used[id]; n++) id = slug(stepName) + '-' + n;
    used[id] = true;
    states.push({ id: id, name: stepName });
    path.push(id);
  }
  var transitions = [{ from: 'off', to: path[0], trigger: 'lifecycle', event: 'play' }];
  for (var j = 0; j + 2 < path.length; j++) {
    transitions.push({ from: path[j], to: path[j + 1], trigger: 'operator', event: 'next' });
  }
  if (path.length >= 2) {
    transitions.push({ from: path[path.length - 2], to: path[path.length - 1], trigger: 'lifecycle', event: 'stop' });
  }
  return { groups: [{ id: 'main', initial: 'off', defaultPath: path, states: states, transitions: transitions }] };
})();

var noacgCurrent = {};      // group id -> current state id (pointers move SYNCHRONOUSLY)
var noacgGroupTl = {};      // group id -> that group's running entry timeline
var noacgTimers = {};       // group id -> the armed gsap.delayedCall (timer transitions)
var noacgQueue = [];        // the serial event queue — one event at a time, FIFO
var noacgDraining = false;  // re-entrancy guard: a dispatch during a drain queues behind
(function () {
  for (var g = 0; g < noacgMachine.groups.length; g++) {
    noacgCurrent[noacgMachine.groups[g].id] = noacgMachine.groups[g].initial;
  }
})();

function noacgPathIndex(stateId) {
  var path = noacgMachine.groups[0].defaultPath || [];
  for (var i = 0; i < path.length; i++) if (path[i] === stateId) return i;
  return -1;
}

// Keep the main pointer in step with the classic walk (machine-less playback).
function noacgTrackPath() {
  var main = noacgMachine.groups[0];
  noacgCurrent[main.id] = noacgStepsPlayed > 0 ? main.defaultPath[noacgStepsPlayed - 1] : main.initial;
}

function noacgStateOf(group, id) {
  for (var i = 0; i < group.states.length; i++) if (group.states[i].id === id) return group.states[i];
  return null;
}

function noacgOperatorEdge(group, from, event) {
  for (var i = 0; i < group.transitions.length; i++) {
    var t = group.transitions[i];
    if (t.from === from && t.trigger === 'operator' && t.event === event) return t;
  }
  return null;
}

function noacgTimerEdge(group, from) {
  for (var i = 0; i < group.transitions.length; i++) {
    var t = group.transitions[i];
    if (t.from === from && t.trigger === 'timer') return t;
  }
  return null;
}

// The materialised entrance/exit edge ('play' or 'stop'), looked up POSITIONALLY at its one
// canonical seat — play: initial → the first waypoint; stop: between the last two waypoints.
// This is how the entrance and the exit carry a transition style; a lifecycle edge anywhere
// else never fires (the editor's validator says so out loud). next() never sees these: the
// walk fires OPERATOR arrows only, so stop's edge never makes another press legal.
function noacgLifecycleEdge(event) {
  var main = noacgMachine.groups[0];
  var path = main.defaultPath || [];
  if (path.length < 2) return null;
  var from = event === 'play' ? main.initial : path[path.length - 2];
  var to = event === 'play' ? path[0] : path[path.length - 1];
  for (var i = 0; i < main.transitions.length; i++) {
    var t = main.transitions[i];
    if (t.trigger === 'lifecycle' && t.event === event && t.from === from && t.to === to) return t;
  }
  return null;
}

function noacgCancelTimer(groupId) {
  if (noacgTimers[groupId]) { noacgTimers[groupId].kill(); noacgTimers[groupId] = null; }
}

function noacgCancelAllTimers() {
  for (var g = 0; g < noacgMachine.groups.length; g++) noacgCancelTimer(noacgMachine.groups[g].id);
}

function noacgResetPointers() {
  for (var g = 0; g < noacgMachine.groups.length; g++) {
    noacgCurrent[noacgMachine.groups[g].id] = noacgMachine.groups[g].initial;
  }
}

// The step a state's content comes from: a default-path state's positional step, an off-path
// state's inline timeline, or null for a pose-only state.
function noacgStepFor(group, stateId) {
  if (group === noacgMachine.groups[0]) {
    var idx = noacgPathIndex(stateId);
    if (idx >= 0) return NOACG_ANIM.steps[idx];
  }
  var state = noacgStateOf(group, stateId);
  return state && state.timeline ? state.timeline : null;
}

// The timeline ENTERING a state plays: a default-path state plays its positional step (the
// first through the entrance recipe, the last through the exit recipe), an off-path state
// its inline timeline, a pose-only state nothing (instant).
function noacgEnterTimeline(group, stateId) {
  if (group === noacgMachine.groups[0]) {
    var idx = noacgPathIndex(stateId);
    if (idx === 0) return noacgEntranceTimeline();
    if (idx > 0 && idx === (group.defaultPath || []).length - 1) return noacgExitTimeline();
  }
  var step = noacgStepFor(group, stateId);
  // Same reason as next(): an event transition is fired on a graphic that is already on air, so
  // the state's opening values have to land on the press rather than a frame later - a quiz sent
  // back from Revealed to Question would otherwise paint one more frame with the answer up.
  return step ? noacgPaintFirstFrame(buildStepTimeline(step)) : null;
}

// Run a step's lifecycle calls once, immediately. Snap composes a pose with SUPPRESSED
// callbacks, which is what keeps clocks and loops idle along the route — but a state whose
// look is painted by a call (a quiz's lock dim) would then snap to an incomplete pose. So
// the TARGET state's own calls run once the pose is composed; the states merely passed
// THROUGH stay suppressed, so nothing replays a side effect on the way.
function noacgFireCalls(step) {
  var calls = (step && step.calls) || [];
  for (var i = 0; i < calls.length; i++) {
    var fn = window[calls[i].call];
    if (typeof fn === 'function') fn();
  }
}

// A timer transition arms when its state's entry timeline SETTLES (a tl.call at the authored
// end). gsap.delayedCall rides the GSAP clock, so time-scaling and callback suppression hold:
// a settled or scrubbed graphic (progress(1, true)) never arms a timer and never
// auto-advances under the operator.
function noacgArmTimer(group, stateId, tl) {
  var edge = noacgTimerEdge(group, stateId);
  if (!edge) return;
  var arm = function () {
    noacgCancelTimer(group.id);
    noacgTimers[group.id] = gsap.delayedCall(edge.after / (NOACG_ANIM.speed || 1), function () {
      noacgTimers[group.id] = null;
      noacgDispatch({ timerGroup: group.id, from: stateId });
    });
  };
  if (tl) tl.call(arm, null, tl.duration());
  else arm();
}

// Payload fields ride an ACCEPTED event, written through the same helper update() uses —
// a bare update() still never causes a transition.
function noacgApplyPayload(payload) {
  for (var key in payload) {
    if (!Object.prototype.hasOwnProperty.call(payload, key)) continue;
    var el = document.getElementById(key);
    if (!el) continue;
    if (typeof setFieldValue === 'function') setFieldValue(el, payload[key]);
    else el.textContent = payload[key];
  }
}

// A STYLED transition (the arrow's own "style": fade, push-left/right/up/down,
// wipe-left/right): the arrow's animated change plays INSTEAD of the target state's entry
// timeline. Two phases on the root — the old pose leaves, the target pose is composed
// instantly (the snap recipe, suppressed callbacks), the new pose arrives — landing exactly
// where the entry timeline would have settled, so a styled entry and a snap agree on every
// pose. An unknown style returns null and the entry timeline plays: honest degradation.
function noacgStyleTimeline(group, edge) {
  var style = edge.style;
  var root = document.querySelector(NOACG_ANIM.root);
  var known = { cut: 1, fade: 1, 'push-left': 1, 'push-right': 1, 'push-up': 1, 'push-down': 1, 'wipe-left': 1, 'wipe-right': 1 };
  if (!style || !root || !known[style]) return null;
  var speed = NOACG_ANIM.speed || 1;
  var half = ((edge.duration || 0.6) / speed) / 2;
  var ease = noacgEaseOf(edge.ease || 'power2.inOut');
  var isPush = style.indexOf('push-') === 0;
  var axis = style === 'push-left' || style === 'push-right' ? 'xPercent' : 'yPercent';
  var sign = style === 'push-left' || style === 'push-up' ? -1 : 1;
  var pose = { v: 0 };
  var swapped = false;
  // The pose swap: compose the CURRENT pointers' pose from a clean slate — the SNAP recipe
  // (clear, then replay every group's canonical route with suppressed callbacks). Composing
  // only the target's entry timeline would be wrong twice over: a pose-only branch state
  // (the quiz's Selected) plays nothing, and the entrance's root reveal lives on the ROUTE,
  // not on the target. Idempotent and exposed on the timeline (__noacgSwap): an interrupting
  // event finishes this timeline with SUPPRESSED callbacks, which would skip a tl.call — so
  // the interrupter runs the swap by hand and the pointer's state is always the DOM's.
  var swap = function () {
    if (swapped) return;
    swapped = true;
    noacgResetGraphic();
    noacgStepsPlayed = 0;
    for (var g = 0; g < noacgMachine.groups.length; g++) {
      var gr = noacgMachine.groups[g];
      var target = noacgCurrent[gr.id];
      if (target === gr.initial) continue;
      var route = noacgCanonicalPath(gr, target);
      if (!route) continue;
      for (var s = 0; s < route.length; s++) {
        var enter = noacgEnterTimeline(gr, route[s]);
        if (enter) { enter.pause(0); enter.progress(1, true); enter.kill(); }
        if (gr === noacgMachine.groups[0]) {
          var idx = noacgPathIndex(route[s]);
          if (idx >= 0) noacgStepsPlayed = idx + 1;
        }
      }
    }
    noacgFireCalls(noacgStepFor(group, edge.to));
  };
  var tl = gsap.timeline();
  // Settling a timeline (progress(1, true) — the editor's parked view, thumbnails, the
  // scrub chain) SUPPRESSES callbacks, which would skip the swap and leave the wrong pose.
  // So the styled timeline's own progress() runs the idempotent swap whenever it is seeked
  // to the end — every consumer of the settle recipe lands right with no caller changes.
  var finishAware = function (built) {
    var origProgress = built.progress;
    built.progress = function (v) {
      var r = origProgress.apply(this, arguments);
      if (typeof v === 'number' && v >= 1) swap();
      return r;
    };
    built.__noacgSwap = swap;
    return built;
  };
  // CUT: the broadcast hard cut — the pose swap alone, no tween on either side. A
  // zero-duration timeline whose one call runs the swap; duration/ease are ignored.
  if (style === 'cut') {
    tl.call(swap);
    return finishAware(tl);
  }
  // Phase 1: the old pose leaves.
  if (style === 'fade') {
    tl.to(root, { opacity: 0, duration: half, ease: ease });
  } else if (isPush) {
    var outVars = { duration: half, ease: ease };
    outVars[axis] = sign * 120;
    tl.to(root, outVars);
  } else {
    tl.to(root, { clipPath: style === 'wipe-left' ? 'inset(0% 100% 0% 0%)' : 'inset(0% 0% 0% 100%)', duration: half, ease: ease });
  }
  // The swap, plus parking the root at the IN phase's starting offset (entering from the
  // side the old pose left toward — a continuous push, a continuous wipe).
  tl.call(function () {
    swap();
    if (style === 'fade') {
      pose.v = Number(gsap.getProperty(root, 'opacity'));
      gsap.set(root, { opacity: 0 });
    } else if (isPush) {
      pose.v = Number(gsap.getProperty(root, axis)) || 0;
      var park = {};
      park[axis] = pose.v - sign * 120;
      gsap.set(root, park);
    } else {
      gsap.set(root, { clipPath: style === 'wipe-left' ? 'inset(0% 0% 0% 100%)' : 'inset(0% 100% 0% 0%)' });
    }
  });
  // Phase 2: the new pose arrives, ending on the CAPTURED pose values (function-based ends
  // read them after the swap ran).
  if (style === 'fade') {
    tl.to(root, { opacity: function () { return pose.v; }, duration: half, ease: ease });
  } else if (isPush) {
    var inVars = { duration: half, ease: ease };
    inVars[axis] = function () { return pose.v; };
    tl.to(root, inVars);
  } else {
    tl.to(root, {
      clipPath: 'inset(0% 0% 0% 0%)',
      duration: half,
      ease: ease,
      onComplete: function () { gsap.set(root, { clearProps: 'clipPath' }); }
    });
  }
  return finishAware(tl);
}

// Fire one transition: the pointer moves SYNCHRONOUSLY (an event arriving mid-animation
// evaluates against the NEW state), the previous group timeline finishes instantly with
// suppressed callbacks (nothing double-fires), the target state's timeline plays, and the
// target's entry timer arms. Entering the exit state takes the graphic off air.
function noacgFire(group, edge) {
  noacgCancelTimer(group.id);
  var prev = noacgGroupTl[group.id];
  if (prev) {
    if (prev.progress() < 1) prev.progress(1, true);
    if (prev.__noacgSwap) prev.__noacgSwap(); // a suppressed finish skipped the pose swap
    prev.kill();
    noacgGroupTl[group.id] = null;
  }
  noacgCurrent[group.id] = edge.to;
  var main = noacgMachine.groups[0];
  if (group === main) {
    var idx = noacgPathIndex(edge.to);
    if (idx >= 0) noacgStepsPlayed = idx + 1;
  }
  var tl = noacgStyleTimeline(group, edge) || noacgEnterTimeline(group, edge.to);
  if (tl) noacgGroupTl[group.id] = tl;
  var path = main.defaultPath || [];
  if (group === main && edge.to === path[path.length - 1]) {
    // The exit was reached (an authored next-drives-out arrow): off air, like stop().
    noacgCancelAllTimers();
    noacgResetPointers();
  } else {
    noacgArmTimer(group, edge.to, tl);
  }
  return tl;
}

// next() under a machine: the default-path walk. On-path it enters the next waypoint
// (whatever event name the authored arrow carries); the arrow INTO the exit is an authored
// opt-in (without one, next() no-ops when only Out remains — the classic contract). Off-path
// it fires an authored 'next' rejoin arrow if the author drew one; otherwise a deterministic
// no-op.
function noacgProcessNext() {
  var main = noacgMachine.groups[0];
  var path = main.defaultPath || [];
  var cur = noacgCurrent[main.id];
  var i = noacgPathIndex(cur);
  if (i < 0 && cur === main.initial && path.length > 0) {
    // Off air: next() does nothing — play() is how the graphic enters.
    return null;
  }
  if (i >= 0) {
    if (i + 1 >= path.length) return null;
    var target = path[i + 1];
    var authored = null;
    for (var k = 0; k < main.transitions.length; k++) {
      var t = main.transitions[k];
      if (t.from === cur && t.to === target && t.trigger === 'operator') { authored = t; break; }
    }
    if (i + 1 === path.length - 1 && !authored) return null;
    return noacgFire(main, authored || { from: cur, to: target, trigger: 'operator' });
  }
  var rejoin = noacgOperatorEdge(main, cur, 'next');
  return rejoin ? noacgFire(main, rejoin) : null;
}

// Process one queued entry. Timer firings re-check their arming state — the graphic may have
// moved while they sat in the queue — so a stale timer is dropped, never misfired.
function noacgProcessOne(e) {
  if (e.timerGroup) {
    for (var g = 0; g < noacgMachine.groups.length; g++) {
      var tg = noacgMachine.groups[g];
      if (tg.id !== e.timerGroup) continue;
      if (noacgCurrent[tg.id] !== e.from) return null;
      var timerEdge = noacgTimerEdge(tg, e.from);
      return timerEdge ? noacgFire(tg, timerEdge) : null;
    }
    return null;
  }
  if (e.pathStep) return noacgProcessNext();
  if (!NOACG_ANIM.machine) {
    // Machine-less templates keep the classic playback exactly; 'next' is their one event.
    return e.event === 'next' ? revealNextStep() : null;
  }
  // Structural guarding: only groups whose CURRENT state has an arrow for this event fire —
  // several may (parallel groups), none means the event is illegal right now and is dropped.
  var firing = [];
  for (var g2 = 0; g2 < noacgMachine.groups.length; g2++) {
    var group = noacgMachine.groups[g2];
    var edge = noacgOperatorEdge(group, noacgCurrent[group.id], e.event);
    if (edge) firing.push({ group: group, edge: edge });
  }
  if (firing.length === 0) return null;
  if (e.payload) noacgApplyPayload(e.payload);
  var last = null;
  for (var f = 0; f < firing.length; f++) {
    var tl = noacgFire(firing[f].group, firing[f].edge);
    if (tl) last = tl;
  }
  return last;
}

// noacgDispatch(event, payload?): send one operator event through the SERIAL queue. Events
// resolve one at a time in arrival order — near-simultaneous events and multi-part updates
// land deterministically and atomically. The optional payload is a flat {field: value} map
// applied only when the event is accepted. Returns the last timeline the event started
// (null when guarded out or queued behind a running drain).
function noacgDispatch(event, payload) {
  noacgQueue.push(typeof event === 'string' ? { event: event, payload: payload } : event);
  if (noacgDraining) return null;
  noacgDraining = true;
  var last = null;
  while (noacgQueue.length > 0) {
    var tl = noacgProcessOne(noacgQueue.shift());
    if (tl) last = tl;
  }
  noacgDraining = false;
  return last;
}

// play() under a machine: the built-in reset-and-enter — every group to its initial state,
// the queue cleared, the entrance played, the first waypoint's timer armed. A STYLE on the
// materialised play edge (cut/fade/push/wipe) plays the styled change instead of the
// entrance timeline, landing on the same settled pose (the swap composes the pointers'
// pose, set below before the timeline runs).
function noacgMachinePlay() {
  noacgCancelAllTimers();
  noacgQueue.length = 0;
  noacgGroupTl = {};
  noacgResetPointers();
  noacgStepsPlayed = 1;
  var main = noacgMachine.groups[0];
  noacgCurrent[main.id] = (main.defaultPath || [])[0];
  var edge = noacgLifecycleEdge('play');
  var tl = (edge && edge.style !== undefined ? noacgStyleTimeline(main, edge) : null) || noacgEntranceTimeline();
  noacgGroupTl[main.id] = tl;
  noacgArmTimer(main, noacgCurrent[main.id], tl);
  return tl;
}

function noacgMachineNext() {
  return noacgDispatch({ pathStep: true });
}

// stop() under a machine: the built-in out — legal from every state, cancels timers, flushes
// the queue, plays the exit, and rests every group at its initial state. A STYLE on the
// materialised stop edge plays the styled change instead of the Out timeline, from WHEREVER
// the graphic is: the pointers rest first, so the swap composes the off pose — and the Out
// step's lifecycle calls still run once at the swap (a clock's stopClock must not be skipped
// just because the exit was styled).
function noacgMachineStop() {
  noacgCancelAllTimers();
  noacgQueue.length = 0;
  var edge = noacgLifecycleEdge('stop');
  var styled = edge && edge.style !== undefined ? noacgStyleTimeline(noacgMachine.groups[0], edge) : null;
  var tl = styled || noacgExitTimeline();
  noacgGroupTl = {};
  noacgResetPointers();
  return tl;
}

// The canonical route to a state: for a main-group waypoint, the default-path prefix; else
// BFS shortest path from the group's initial over authored operator/timer arrows
// (data-condition never fires) plus the walk's own edges, ties resolved by declaration
// order. Mirrors blocks/animMachine.ts canonicalPath — keep them in agreement.
function noacgCanonicalPath(group, targetId) {
  if (targetId === group.initial) return [];
  var isMain = group === noacgMachine.groups[0];
  var path = group.defaultPath || [];
  if (isMain) {
    var pi = noacgPathIndex(targetId);
    if (pi >= 0) return path.slice(0, pi + 1);
  }
  var edges = [];
  if (isMain && path.length > 0) {
    edges.push({ from: group.initial, to: path[0] });
    for (var w = 0; w + 1 < path.length; w++) edges.push({ from: path[w], to: path[w + 1] });
  }
  for (var i = 0; i < group.transitions.length; i++) {
    if (group.transitions[i].trigger !== 'data-condition') edges.push(group.transitions[i]);
  }
  var cameFrom = {};
  var seen = {};
  seen[group.initial] = true;
  var queue = [group.initial];
  while (queue.length > 0) {
    var at = queue.shift();
    for (var e = 0; e < edges.length; e++) {
      var edge = edges[e];
      if (edge.from !== at || seen[edge.to]) continue;
      seen[edge.to] = true;
      cameFrom[edge.to] = at;
      if (edge.to === targetId) {
        var route = [];
        var id = targetId;
        while (id !== group.initial) { route.unshift(id); id = cameFrom[id]; }
        return route;
      }
      queue.push(edge.to);
    }
  }
  return null;
}

// Return the graphic to its CSS rest: clear every inline style the animations wrote.
// Self-contained (no editor needed), so snap works identically in exports.
function noacgResetGraphic() {
  if (noacgOutTimeline) noacgOutTimeline.kill();
  noacgOutTimeline = null;
  noacgLiveTimeline = null;
  var root = document.querySelector(NOACG_ANIM.root);
  if (root) {
    gsap.set(root, { clearProps: 'all' });
    var all = root.querySelectorAll('*');
    for (var i = 0; i < all.length; i++) gsap.set(all[i], { clearProps: 'all' });
  }
  // clearProps wipes INLINE styles, and one of them is not the animation's to wipe: an image
  // field with no picture is hidden inline (setFieldValue removes the src and sets
  // display:none), so clearing it turns an empty field into a 52px broken-image box on air.
  // Re-hide every srcless field image — the data layer's truth, restated after the reset.
  var imgs = document.querySelectorAll('img[id]');
  for (var m = 0; m < imgs.length; m++) {
    if (!imgs[m].getAttribute('src')) imgs[m].style.display = 'none';
  }
  // Press-revealed layers can sit OUTSIDE the root — clear them too.
  for (var s = 1; s < NOACG_ANIM.steps.length - 1; s++) {
    var reveals = NOACG_ANIM.steps[s].reveals || [];
    for (var r = 0; r < reveals.length; r++) {
      var el = document.querySelector(reveals[r]);
      if (el) gsap.set(el, { clearProps: 'all' });
    }
  }
}

// noacgSnap(assignments, opts?): enter states INSTANTLY — no animation replay. assignments
// is a {groupId: stateId} map; groups not named keep their current state; null means every
// group to its initial — the VISUAL half of reset (data reset stays update()'s job, the two
// are never conflated). The pose is composed by replaying each group's canonical path with
// suppressed callbacks, so clocks, loops and timers stay silent during composition. Entry
// timers then arm by default (recovery: a snapped-into ticker resumes cycling); pass
// { timers: false } to park the graphic (the editor's preview does).
function noacgSnap(assignments, opts) {
  opts = opts || {};
  var want = {};
  var g, group;
  for (g = 0; g < noacgMachine.groups.length; g++) {
    group = noacgMachine.groups[g];
    var target = assignments === null || assignments === undefined
      ? group.initial
      : (assignments[group.id] !== undefined ? assignments[group.id] : noacgCurrent[group.id]);
    if (!noacgStateOf(group, target)) target = group.initial;
    want[group.id] = target;
  }
  noacgCancelAllTimers();
  noacgQueue.length = 0;
  gsap.killTweensOf('*');
  noacgGroupTl = {};
  noacgResetGraphic();
  noacgStepsPlayed = 0;
  noacgResetPointers();
  for (g = 0; g < noacgMachine.groups.length; g++) {
    group = noacgMachine.groups[g];
    if (want[group.id] === group.initial) continue;
    var route = noacgCanonicalPath(group, want[group.id]);
    if (!route) continue; // unreachable — the group rests at its initial state
    for (var s = 0; s < route.length; s++) {
      var tl = noacgEnterTimeline(group, route[s]);
      if (tl) { tl.pause(0); tl.progress(1, true); tl.kill(); }
      noacgCurrent[group.id] = route[s];
      if (group === noacgMachine.groups[0]) {
        var idx = noacgPathIndex(route[s]);
        if (idx >= 0) noacgStepsPlayed = idx + 1;
      }
    }
    noacgFireCalls(noacgStepFor(group, want[group.id])); // the target state's own effects
    if (opts.timers !== false) noacgArmTimer(group, want[group.id], null);
  }
  return noacgMachineState();
}

// A copy of the machine's pointers — for tests, the editor's state chip, and recovery.
function noacgMachineState() {
  var out = { groups: {} };
  for (var g = 0; g < noacgMachine.groups.length; g++) {
    var id = noacgMachine.groups[g].id;
    out.groups[id] = noacgCurrent[id];
  }
  return out;
}
/* == END ANIMATION == */


// Hold every line to the room this design gives it, so the panel never grows taller than
// it was drawn. Called after each update() (see update() above) and once the fonts are in.
//
// The room is measured ONCE, from the design's own sample text, and remembered on the element:
// that is "the rows this line was drawn for". Everything the operator types afterwards is fitted
// into it by reducing the font size, never past STAGE_FIT_MIN of the design size.
var STAGE_FIT_MIN = 0.55;        // never shrink below 55% of the size the design asks for
// …and never below the CATALOG'S OWN TYPE FLOOR either, whatever the design size was. 55% of a
// 32px letter is 17.6px, which is under the 20px this catalogue holds every graphic to
// (scripts/type-floor.mjs, DESIGN_LANGUAGE §1) - so the relative floor alone let the fit shrink
// text into illegibility and the type-floor gate caught four variants doing it. Past this point
// a tight line is the better failure: the words stay readable and the panel still holds.
var STAGE_FIT_FLOOR_PX = 20;
var stageCalibrated = false;     // true once the design's own sample has been measured

// A RESERVE IS A LAYOUT NUMBER, AND A RECT IS THE VISUAL BOX - the two stop agreeing the moment
// anything above the line is TRANSFORMED. `getBoundingClientRect` reports the box after every
// ancestor transform has been applied, so a line inside a CSS-animated badge is measured through
// whatever that animation was doing on the frame the fit happened to run. Both halves of that were
// shipping (measured 2026-08-23/24, on the run that made e2e/catalog-baseline.spec.ts flake with a
// DRIFTING element set - nothing about the graphics had moved, the measurement had):
//
//   - gt03's badge SCALES as it pops, so its clock reserved 412px, 417px and 418px across three
//     runs for an element that is 400px in layout - the reserve was the pop, frozen at whatever
//     moment the fit landed on.
//   - gt04's badge only TRANSLATES, which should cost nothing - but the rect still comes back
//     through the composited matrix, so its height alternates between 399.9999694824219 and
//     400.0000305175781 from frame to frame, and `Math.ceil` turns that into 400 or 401.
//
// So the reserve is read off the LAYOUT box instead. `getComputedStyle().height` is the used
// height in px - sub-pixel, and blind to transforms, which is exactly the difference that matters
// (`offsetHeight` is blind to them too but rounds to a whole pixel, and a reserve rounded DOWN is
// a clipped design). It is the content box unless the element says otherwise, so the padding and
// border are added back to keep this the border box the rest of this file measures in.
//
// Snapped to 1/64 px, Blink's own layout unit, so a used value that comes back with a float tail
// still lands on one number every time. A genuine sub-pixel reserve (188.5) is untouched and still
// rounds up to a whole 189 where the caller asks for that.
function stageLayoutHeight(el, cs) {
  var h = parseFloat(cs.height);
  if (!(h >= 0)) return Math.round(el.getBoundingClientRect().height * 64) / 64;  // not laid out
  if (cs.boxSizing !== 'border-box') {
    h += (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0) +
      (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
  }
  return Math.round(h * 64) / 64;
}

// THE PANELS THIS RUNTIME LOOKS AFTER, kept in a shared list rather than baked into each
// function as one selector.
//
// It matters when a graphic is INSERTED into another (blocks/templateInsert.ts). Both templates
// carry this same runtime, so the merged file declares these functions twice and the later
// declaration wins - and if each copy had its own hardcoded selector, the losing graphic would
// silently stop being fitted. Registering the selector instead means whichever copy survives
// still fits BOTH panels, which is what makes the duplicate harmless rather than quietly
// destructive. It is also why these names can sit in that file's scaffold allowlist honestly:
// they are assembler scaffolding, like setFieldValue, not design-owned logic.
var STAGE_FIT_BOXES = (window.__noacgStageFitBoxes = window.__noacgStageFitBoxes || []);
if (STAGE_FIT_BOXES.indexOf('.quiz-box') < 0) STAGE_FIT_BOXES.push('.quiz-box');

function stageFitBoxes() {
  var found = [];
  for (var i = 0; i < STAGE_FIT_BOXES.length; i++) {
    var els = document.querySelectorAll(STAGE_FIT_BOXES[i]);
    for (var j = 0; j < els.length; j++) found.push(els[j]);
  }
  return found;
}

// One row of this line, at the size the design asks for. `line-height: normal` computes to a
// keyword rather than a number on some faces, so fall back to the CSS default ratio.
function stageLineHeight(el, cs, design) {
  var line = parseFloat(cs.lineHeight);
  return (line && !isNaN(line)) ? line : design * 1.2;
}

// ONE ROW'S CONTENT HEIGHT for this element's face - a DIFFERENT box from the one above, and the
// distinction is the whole reason this function exists. `line-height` says how much room a row
// TAKES; the FACE decides how tall its own glyph box IS, and on most of the bundled faces that is
// about 1.2em whatever line-height says (measured: Space Grotesk 1.17, Inter 1.14, Manrope 1.24,
// Oswald 1.29, Saira 1.35). `scrollHeight` reads the second box, so a row drawn with the tighter
// line-height of the two reports an overflow that is not there and shrinks for nothing.
//
// Measured once per face and cached on the window, for the same reason the box list is: a board
// rebuilds its rows on every update, and a graphic inserted into another carries a second copy of
// this file. The probe is a zero-height, zero-leading box, so its scrollHeight is the glyph box
// and nothing else.
var STAGE_FACE_RATIOS = (window.__noacgStageFaceRatios = window.__noacgStageFaceRatios || {});
function stageFaceHeight(cs, design) {
  var key = cs.fontFamily + '|' + cs.fontWeight + '|' + cs.fontStyle;
  var ratio = STAGE_FACE_RATIOS[key];
  if (!ratio) {
    var probe = document.createElement('div');
    probe.style.cssText = 'position:absolute;left:-9999px;top:0;height:0;line-height:0;white-space:nowrap;visibility:hidden';
    probe.style.fontFamily = cs.fontFamily;
    probe.style.fontWeight = cs.fontWeight;
    probe.style.fontStyle = cs.fontStyle;
    probe.style.fontSize = '100px';
    probe.textContent = 'Hxpg';                 // an ascender, an x-height, two descenders
    document.body.appendChild(probe);
    ratio = probe.scrollHeight / 100;
    document.body.removeChild(probe);
    if (!(ratio > 0)) ratio = 1.2;              // a face that will not measure gets the CSS default
    STAGE_FACE_RATIOS[key] = ratio;
  }
  return ratio * design;
}

// EVERY LEAF TEXT ELEMENT inside the staged panel, not just the masked lines the presets
// choreograph. A poll's option rows, a standings board's names and a queue's entries are built by
// the design's own runtime from a textarea, so they carry no mask - and they are exactly where
// the remaining height came from once the masked lines were held. A leaf that already fits is
// left alone, so widening the net costs nothing on the designs that did not need it.
function stagedLines() {
  var boxes = stageFitBoxes();
  var all = [];
  for (var b = 0; b < boxes.length; b++) {
    var kids = boxes[b].querySelectorAll('*');
    for (var k = 0; k < kids.length; k++) all.push(kids[k]);
  }
  var out = [];
  for (var i = 0; i < all.length; i++) {
    var el = all[i];
    if (el.children.length) continue;                       // not a leaf: its children carry the text
    var text = (el.textContent || '').trim();
    if (!text) continue;                                    // nothing to fit
    // A one- or two-character leaf is a glyph, a letter chip or a single digit: it cannot
    // wrap, so it has no room to be held to - and reserving one clipped sn03's avatar, whose
    // icon sits inside a fixed circular frame that was never ours to resize.
    if (text.length < 3) continue;
    if (el.className && String(el.className).indexOf('noacg-data-source') >= 0) continue;
    // A DESIGN THAT ALREADY BOUNDS ITS OWN LINE IS LEFT ALONE. `-webkit-line-clamp` is the
    // author saying how many rows this line may have; imposing a reserve on top of that fights
    // a decision already made, and the audience pack's own gate caught it - a clamped question
    // ended up taller than the clamp allows. The rule is the one the stage follows everywhere:
    // where the design has stated the room, the runtime does not restate it.
    var clamp = window.getComputedStyle(el).webkitLineClamp;
    if (clamp && clamp !== 'none') continue;
    out.push(el);
  }
  return out;
}

function fitStagedText() {
  var lines = stagedLines();
  for (var i = 0; i < lines.length; i++) fitOneStagedLine(lines[i]);
  holdStageHeight();
}

// THE OUTER GUARANTEE. Fitting the lines is what SHOULD keep the panel its own size, and on a
// design whose text is all in lines it does. It is not enough on a board whose runtime rebuilds
// its own rows: the row elements are replaced wholesale on every update, so anything remembered
// on them is gone, and one reflow the fit did not see would move the panel again. Reserving the
// panel's own height closes that for good - measured once, from the design's own content, on the
// same terms as everything else here.
function holdStageHeight() {
  var boxes = stageFitBoxes();
  for (var i = 0; i < boxes.length; i++) holdOneStageBox(boxes[i]);
}

function holdOneStageBox(box) {
  var room = parseFloat(box.getAttribute('data-stage-room') || '');
  if (!room) {
    box.style.height = '';
    // The panel's own reserve reads the layout box for the same reason its lines do: a panel
    // whose content animates would otherwise reserve whatever that animation was mid-way through.
    room = stageLayoutHeight(box, window.getComputedStyle(box));
    if (!room) return;
    box.setAttribute('data-stage-room', room);
  }
  box.style.boxSizing = 'border-box';   // the reserve is the border box it was measured from
  // HEIGHT, and deliberately NOT overflow:hidden - the same lesson as the lines above, one
  // level up. The height is what holds the panel; hiding the overflow as well cut content on
  // 17 designs at their OWN default text. If a value ever beats the shrink floor it bleeds a
  // little rather than losing words, and the panel still has not moved.
  // A FLOOR, not a fixed height. The panel must not SHRINK when a value is short - that is the
  // wobble - but it has to be allowed to grow when a value is so long that the shrink hits the
  // 20px type floor and still does not fit. Pinning it there instead makes the runtime bench
  // fail with siblings overlapping by 71%: with the words held at a legible size and the panel
  // refusing to give, the only thing left to collide is the content.
  box.style.minHeight = room + 'px';
}

// THE WIDTH OF THE TEXT ITSELF, and deliberately NOT `scrollWidth`. A design's backdrop is often
// a pseudo-element that OVERHANGS its box on purpose - ss02's slab and chip both lean -8deg, and
// a skewed absolutely-positioned layer counts towards the element's scrollable overflow. So
// scrollWidth reported 936 against a 920px row and the runtime read a painted lean as the
// headline running out of its box: 92px shipped at 66px, at the design's own default words.
// A Range over the element's own text nodes measures letters and nothing else, and on a wrapped
// block its rects are the line boxes - so the widest ROW is what gets compared, which is the
// number that decides whether anything is actually outside the box.
function stageTextWidth(el) {
  if (!document.createRange) return el.scrollWidth;
  var range = document.createRange();
  range.selectNodeContents(el);
  var rects = range.getClientRects();
  var widest = 0;
  for (var i = 0; i < rects.length; i++) if (rects[i].width > widest) widest = rects[i].width;
  return widest || el.scrollWidth;
}

// The room across, on the same terms: the CONTENT box, since that is the box the text sits in.
// Taken from the RECT and not from `clientWidth`, because clientWidth is rounded to whole pixels
// and the text width beside it is not - and half a pixel on a chip 50px across is a 1% overflow
// that is not there. Seventeen designs sat just past the fit's 0.5% tolerance on nothing else.
// `clientWidth` still answers one question the rect cannot: an inline box reports 0 there, and an
// inline box has no content width to hold anything to.
function stageContentWidth(el, cs) {
  if (!el.clientWidth) return 0;
  var w = el.getBoundingClientRect().width
    - (parseFloat(cs.borderLeftWidth) || 0) - (parseFloat(cs.borderRightWidth) || 0)
    - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0);
  return w > 0 ? w : 0;
}

// THE BOX A LINE IS DRAWN IN, if it has one: the nearest ancestor that actually paints - a tile,
// a chip, a coloured severity square. That box is FURNITURE, and furniture does not stretch to fit
// a longer word; the words fit the furniture. Found by walking up rather than by class name, so it
// works on any design without being told which of its elements are boxes.
function drawnBoxOf(el) {
  for (var p = el.parentNode; p && p.nodeType === 1 && p !== document.body; p = p.parentNode) {
    var cs = window.getComputedStyle(p);
    var bg = cs.backgroundColor;
    if (cs.backgroundImage && cs.backgroundImage !== 'none') return p;
    if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') return p;
    if (parseFloat(cs.borderTopWidth) > 0 || parseFloat(cs.borderLeftWidth) > 0) return p;
  }
  return null;
}

// Everything this runtime pins on a line, taken back off. Used by the recalibration below, which
// has to put every line back to the design's own CSS BEFORE it measures any of them - the fit runs
// in document order, so anything still pinned is a sibling whose height is about to decide the
// reserve of the line being measured.
function stageUnpin(el) {
  el.style.fontSize = '';
  el.style.maxWidth = '';
  el.style.height = '';
  el.style.whiteSpace = '';
  el.style.overflowWrap = '';
  el.style.textAlign = '';
  el.style.display = '';
}

function fitOneStagedLine(el) {
  el.style.fontSize = '';                       // back to the design size before measuring
  el.style.maxWidth = '';
  var cs = window.getComputedStyle(el);
  var design = parseFloat(cs.fontSize);
  if (!design) return;

  // A LINE INSIDE A DRAWN BOX IS GOVERNED BY THAT BOX, not by its own calibrated reserve. The
  // reserve says "this line had one row when the design was drawn", which is the right rule for a
  // line standing on its own and the wrong one inside a tile: the tile has its own width and
  // height, and a label that outgrows them runs straight out of the colour. The owner caught
  // exactly this on the alert strip, where "ADVISORY" became "ADVISORY WISNIEWSKA" and left the
  // blue square on both sides - a defect every gate here missed, because they all measured
  // whether the PANEL moved and none asked whether the text stayed inside its own box.
  var box = drawnBoxOf(el);
  var limitW = 0;
  var room = 0;
  // WHAT THE DESIGN'S OWN SAMPLE ACTUALLY FILLED, remembered beside the reserve and used for
  // nothing else. `room` is a LINE BOX and the overflow test below reads a CONTENT box; measuring
  // the reserve in one and the excess in the other made every line whose line-height sits under
  // its face's content ratio report an overflow at the design's OWN default text and shrink
  // permanently, with no operator input at all. Measured 2026-08-23 across the 290 staged
  // designs: 200 of them shipped a smaller font than their CSS declares, worst -23%, on 457 of
  // 459 shrunk lines - a designer typing 103px and getting 79px. So the excess is measured
  // against what this line settled at when the design was drawn: its own sample fits itself by
  // definition, and only what the operator types PAST it shrinks.
  var fill = 0;

  // THE LINE MAY BE ITS OWN BOX. On the alert strip the severity tile IS the label element - the
  // blue square is that element's own background - so looking at ANCESTORS finds only the panel,
  // which the label sits happily inside while spilling out of the colour it is painted on. The
  // element's own TEXT against its own content box is the honest test, and it is also the
  // discriminator that leaves an auto-width chip alone: a box that grows with its text never
  // reports an overflow, so only a box with a width of its own is ever touched here.
  var contentW = stageContentWidth(el, cs);
  if (contentW > 0 && stageTextWidth(el) > contentW + 2) {
    limitW = contentW;
    // BOTH AXES COME FROM THE BOX AS DRAWN, and the height has to be the one measured at
    // calibration rather than the one it happens to have now: an auto-height element grows as it
    // wraps, so reading it live gives a ceiling that keeps rising and the line just keeps
    // wrapping. al03 then wrapped its way straight through the bottom of the alert panel and the
    // runtime bench caught it clipped mid-line. A tall tile still affords two rows; a one-row
    // slot still has to shrink. The box as drawn decides which.
    room = parseFloat(el.getAttribute('data-stage-selfh') || '');
    if (!room) {
      room = el.clientHeight - (parseFloat(cs.paddingTop) || 0) - (parseFloat(cs.paddingBottom) || 0);
      if (room > 0) el.setAttribute('data-stage-selfh', room);
    }
    if (!(room > 0)) room = 0;
    if (limitW > 0) {
      el.style.whiteSpace = 'normal';
      el.style.overflowWrap = 'break-word';
      el.style.height = '';
      box = el;                                 // it governs itself; centring below still applies
      // The same sample-fill the calibrated branch below records, on the same terms: the box as
      // drawn decides the ROOM, and what the design's own words filled decides what "past it"
      // means. Read after the height is cleared, so it is the content and not the pin.
      fill = parseFloat(el.getAttribute('data-stage-selffill') || '');
      if (!fill && !stageCalibrated) {
        fill = el.scrollHeight;
        if (fill) el.setAttribute('data-stage-selffill', fill);
      }
    }
  }

  // ONLY THE SELF-BOX CASE INTERVENES. A line overflowing an ANCESTOR that paints is real and the
  // sweep reports it, but the runtime does not touch it: the box is somebody else's layout, and
  // wrapping a line inside it moved panels the catalogue has its own contracts about - the sports
  // gate caught .scoreboard-event wrapping into ten rows and taking sb19 210px past what a card
  // may grow. The defect the owner found was the other kind: the alert tile IS the label element,
  // and that one the line can fix without reaching into a layout it does not own.
  if (box && box !== el) box = null;

  // The reserve, remembered from the first measurement - the design's own sample decides it.
  if (!limitW) {
    room = parseFloat(el.getAttribute('data-stage-room') || '');
    fill = parseFloat(el.getAttribute('data-stage-fill') || '');
  }
  if (!limitW && !room) {
    if (stageCalibrated) {
      // A line the design never showed us: it was BUILT by the design's own runtime after load
      // (a poll's options, a standings row, a queue entry), so a rebuild wipes the reserve every
      // time and re-measuring here would take it from the operator's value instead of the
      // design's. One row is the honest answer for a row - that is what a row is - and it is
      // what a board does with a long club name: keep the row, shrink the name.
      room = stageLineHeight(el, cs, design);
      // ONE ROW IS ONE ROW IN BOTH BOXES. The reserve is the row's line box; what has to fit
      // inside it is the row's glyph box, and on a face whose content ratio beats the design's
      // line-height those are not the same number. Taking the row's own face here is what keeps
      // a short club name at full size instead of shrinking it for a wrap that never happened.
      fill = stageFaceHeight(cs, design);
    } else {
      el.style.height = '';                     // measure the natural block, not a reserve
      if (cs.display === 'inline') el.style.display = 'inline-block';
      // The RENDERED height, not scrollHeight: the latter answers "does this overflow", and
      // leaves out the box's own bottom padding, which under-reserves and then clips at the
      // design's OWN content - 37 variants did exactly that.
      // Round up: a reserve a sub-pixel short of the design's own line is a clipped design.
      // Off the LAYOUT height, so the round-up answers the design and not whatever an animated
      // ancestor was doing on this frame - see the note on stageLayoutHeight above.
      room = Math.ceil(stageLayoutHeight(el, cs));
      // …and the overflow the design already had at its own sample, which is the number the
      // shrink test needs and the rect cannot give.
      fill = el.scrollHeight;
    }
    if (!room) return;                          // not laid out yet; a later pass will catch it
    el.setAttribute('data-stage-room', room);
    if (fill) el.setAttribute('data-stage-fill', fill);
  }
  // A real HEIGHT, not a max-height. A cap stops the line growing and lets it SHRINK, so a
  // short value still moves the panel - just in the other direction, which is the same defect
  // wearing the opposite sign. Measured 2026-08-20: with a cap, alert still moved 16px and
  // public-info 27px between a short value and a long one, entirely at the short end.
  // INLINE-BLOCK, never block. A height needs a block-level box, but promoting an inline span
  // to full block makes it fill its parent instead of shrink-wrapping, which re-wraps the row
  // around it and clipped 9 designs sideways at their OWN content.
  if (cs.display === 'inline') el.style.display = 'inline-block';
  // …AND NEVER ON A MULTI-COLUMN BLOCK. A definite height is what tells a multicol container to
  // stop balancing: it fills the first column to that height, the second, and then keeps going
  // into OVERFLOW COLUMNS to the RIGHT - outside the box, where the design's reveal mask clips
  // them away. So the words do not bleed a hair past the bottom, they disappear sideways, and
  // both of the probes below report a comfortable fit while it happens: scrollHeight sees no
  // vertical overflow because there is none, and a Range's rects are line boxes INSIDE a column,
  // each one narrower than the box. card80's two-column standfirst sat 0.25px inside its own
  // reserve at its own sample text, so the nightly's renderer spilled a third column where this
  // one does not (issue #36).
  //
  // An indefinite height is what the shrink lever needs anyway: with the height left alone the
  // container balances into the columns the design asked for and grows DOWNWARD, which is the
  // overflow scrollHeight can see - so the loop below shrinks the type to the reserve exactly as
  // it does for every other line, instead of being blind to it.
  var multicol = cs.columnCount !== 'auto' || cs.columnWidth !== 'auto';
  // HEIGHT ONLY, never overflow:hidden. The height is what holds the layout - that is the whole
  // contract. Hiding the excess as well only CUTS the words when the reserve is a sub-pixel
  // short, which the overflow gate caught on eleven designs at their OWN content; a hair of
  // bleed is a better failure than a clipped letter.
  el.style.height = multicol ? '' : room + 'px';

  // The bigger of the two floors wins: a design already at the floor never shrinks at all.
  var floor = Math.max(design * STAGE_FIT_MIN, Math.min(design, STAGE_FIT_FLOOR_PX));
  // The excess is measured against the LARGER of the two: the room the design gave the line, and
  // what the design's own words filled it with. The reserve stays the room - that is what holds
  // the panel - but "too tall" has to mean taller than the design ever was, never taller than a
  // box the browser was never going to keep the glyphs inside.
  var over = Math.max(room, fill || 0);
  for (var pass = 0; pass < 4; pass++) {
    var tallBy = over > 0 ? (el.scrollHeight / over) : 1;
    // Sideways too: a line inside a fixed row or a HELD chip cannot reflow, so it runs out of the
    // box's side rather than off its bottom. Same lever, same floor - only the axis differs.
    // Against the BOX when there is one - a line whose own width is free grows with its text, so
    // its own box and its text agree forever and it never reports the overflow that is plainly
    // there on screen. What it has to fit inside is the furniture around it.
    var wideBy = 1;
    var limit = limitW > 0 ? limitW : stageContentWidth(el, window.getComputedStyle(el));
    if (limit > 0) wideBy = stageTextWidth(el) / limit;
    if (tallBy <= 1.005 && wideBy <= 1.005) break;    // it fits - leave the size alone
    var current = parseFloat(window.getComputedStyle(el).fontSize);
    // A wrapped block's height falls with the SQUARE of the size (shorter text, shorter rows),
    // so the linear ratio overshoots; the square root converges in about two passes. Width is
    // linear in the size, so that axis takes the ratio as it stands.
    var byHeight = tallBy > 1 ? Math.sqrt(1 / tallBy) : 1;
    var byWidth = wideBy > 1 ? (1 / wideBy) : 1;
    var next = Math.max(floor, current * Math.min(byHeight, byWidth));
    if (next >= current) break;                 // no progress left to make
    el.style.fontSize = next + 'px';
    if (next === floor) break;                  // at the floor: as small as it may go
  }

  // ONCE IT HAS WRAPPED, CENTRE IT. A label that took two rows inside a tile was drawn as one,
  // and a ragged left edge in a coloured square reads as a mistake rather than a choice; centred,
  // two short rows read as the label they are. Only inside a drawn box, and only once the line
  // actually occupies more rows than the design gave it - a single row keeps the alignment its
  // designer chose.
  if (box) {
    var lh = stageLineHeight(el, window.getComputedStyle(el), design);
    if (lh > 0 && el.scrollHeight > lh * 1.5) el.style.textAlign = 'center';
  }
}

// Measure the design's own rows before any update() arrives. This file loads in <head>, so the
// lines do not exist yet - wait for the DOM, then again for the webfonts: the design's face loads
// with font-display: swap, and the FALLBACK wraps differently, so a reserve taken before the swap
// would be the wrong number of rows.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', fitStagedText);
} else {
  fitStagedText();
}
if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
  document.fonts.ready.then(function () {
    // Re-measure from scratch: the reserve taken against the fallback face is not this design's.
    // EVERY remembered number goes, not just the reserve - a sample-fill or a drawn-box height
    // measured against the fallback is the fallback's, by exactly the same argument, and a face
    // ratio keyed on a family whose file had not arrived is measuring the substitute.
    STAGE_FACE_RATIOS = window.__noacgStageFaceRatios = {};
    var lines = stagedLines();
    for (var i = 0; i < lines.length; i++) {
      lines[i].removeAttribute('data-stage-room');
      lines[i].removeAttribute('data-stage-fill');
      lines[i].removeAttribute('data-stage-selfh');
      lines[i].removeAttribute('data-stage-selffill');
      // …AND WHAT THE FIRST PASS PINNED, on EVERY line, before ANY line is re-measured. Each line
      // clears its own before measuring itself, which is not the same thing: the lines are fitted
      // in order, so while line 1 is being measured lines 2..n are still holding the FALLBACK
      // pass's heights, and a row pinned half a pixel off its natural height moves the box the
      // line above it is measured in. Measured on the alert strip: its severity tiles reserved 188
      // with the siblings still pinned and 189 from a clean sheet - a whole pixel of the shipped
      // reserve decided by leftovers.
      stageUnpin(lines[i]);
    }
    var boxes = stageFitBoxes();
    for (var b = 0; b < boxes.length; b++) {
      boxes[b].removeAttribute('data-stage-room');
      boxes[b].style.height = '';
      // …AND THE RESERVE ITSELF, which is the one number the first version of this forgot. The
      // panel's reserve is written as a `min-height`, so leaving it in place while re-measuring
      // makes the fallback pass a FLOOR under the real one: the panel can only ever come back the
      // same or taller, and what it keeps is whatever the substitute face happened to fill. Which
      // face the first pass saw is decided by whether the woff2 had arrived by DOMContentLoaded -
      // a property of the machine's load, not of the design - so this is how a timing difference
      // became a shipped reserve. Measured on the alert strip: 189px held against a real 188.5px,
      // and its four severity tiles, sized inside that panel, moved with it.
      boxes[b].style.minHeight = '';
    }
    fitStagedText();
    // Calibration is over: from here the design's own content has been seen, and anything that
    // appears later was built by the design's runtime rather than drawn by its author.
    stageCalibrated = true;
  });
} else {
  stageCalibrated = true;
}