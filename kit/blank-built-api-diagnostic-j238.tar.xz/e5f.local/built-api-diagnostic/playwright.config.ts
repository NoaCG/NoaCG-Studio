import { defineConfig } from '@playwright/test';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import base from '../../playwright.config';
const root = fileURLToPath(new URL('../..', import.meta.url));
const absolute = (p: string) => path.resolve(root, p);
const servers = Array.isArray(base.webServer) ? base.webServer : [base.webServer];
if (servers.some(entry => !entry?.command)) throw new Error('Diagnostic requires original nonempty webServer commands');
export default defineConfig({
  ...base,
  testDir: absolute('e2e'),
  globalSetup: absolute('e2e/_offline-guard.ts'),
  tsconfig: absolute('e5f.local/built-api-diagnostic/tsconfig.observe.json'),
  reporter: (base.reporter as any[]).map(([name, options]) => [name.startsWith('./') ? absolute(name) : name, options]),
  webServer: servers.map(entry => ({ ...entry!, cwd: root })),
  use: { ...base.use, trace: { ...(typeof base.use?.trace === 'object' ? base.use.trace : {}), mode: 'on', snapshots: false } },
});
