# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor-projects.spec.ts >> external draft is durably retained through project api
- Location: e2e/editor-projects.spec.ts:588:77

# Error details

```
Error: page.evaluate: Execution context was destroyed, most likely because of a navigation.
```

# Page snapshot

```yaml
- main [ref=e4]:
  - generic [ref=e5]:
    - generic [ref=e6]:
      - img [ref=e7]
      - generic [ref=e11]:
        - generic [ref=e12]: NoaCG
        - generic [ref=e13]: Studio
    - button "Home" [ref=e14] [cursor=pointer]
    - button "+ New graphic" [ref=e15] [cursor=pointer]
    - generic [ref=e16]: E4 Intro
    - generic [ref=e17]: Editor Alpha
    - button "Assistant" [ref=e18] [cursor=pointer]
    - generic [ref=e19]:
      - generic [ref=e20]: ● Not saved
      - button "💾 Save" [ref=e21] [cursor=pointer]
      - button "▾" [ref=e22] [cursor=pointer]
  - generic [ref=e23]:
    - button "Project ▸" [ref=e24] [cursor=pointer]
    - generic [ref=e25]: E4 Intro
    - generic [ref=e26]: Editing
    - navigation "Group breadcrumbs" [ref=e27]:
      - button "Composition" [ref=e28] [cursor=pointer]
  - generic [ref=e29]:
    - text: ▸
    - region "Graphic canvas" [ref=e30]:
      - generic [ref=e31]:
        - button "select tool" [pressed] [ref=e32] [cursor=pointer]: Select
        - button "anchor tool" [ref=e33] [cursor=pointer]: Anchor
        - button "text tool" [ref=e34] [cursor=pointer]: Text
        - button "rectangle tool" [ref=e35] [cursor=pointer]: Rectangle
        - button "ellipse tool" [ref=e36] [cursor=pointer]: Ellipse
        - button "pen tool" [ref=e37] [cursor=pointer]: Pen
        - button "image tool" [ref=e38] [cursor=pointer]: Image
        - button "Add image file…" [ref=e39] [cursor=pointer]
        - generic [ref=e40]: 1920 × 1080
        - combobox "Canvas zoom" [ref=e41] [cursor=pointer]:
          - option "50% of Fit"
          - option "Fit" [selected]
          - option "150% of Fit"
          - option "200% of Fit"
          - option "400% of Fit"
        - button "Fit" [ref=e42] [cursor=pointer]
      - generic "Arrange artwork" [ref=e43]:
        - generic [ref=e44]:
          - generic [ref=e45]:
            - text: Align to
            - combobox "Align to" [ref=e46] [cursor=pointer]:
              - option "Selection" [selected]
              - option "Canvas"
          - group "Align" [ref=e47]:
            - button "Align left" [disabled] [ref=e48]: Left
            - button "Align horizontal center" [disabled] [ref=e49]: Center
            - button "Align right" [disabled] [ref=e50]: Right
            - button "Align top" [disabled] [ref=e51]: Top
            - button "Align vertical center" [disabled] [ref=e52]: Middle
            - button "Align bottom" [disabled] [ref=e53]: Bottom
          - group "Distribute" [ref=e54]:
            - generic [ref=e55]: Gaps
            - button "Distribute horizontally" [disabled] [ref=e56]: Horizontal
            - button "Distribute vertically" [disabled] [ref=e57]: Vertical
          - generic [ref=e58]:
            - button "Group selection" [disabled] [ref=e59]: Group
            - button "Ungroup selection" [disabled] [ref=e60]: Ungroup
            - button "Enter group" [disabled] [ref=e61]: Edit group
      - generic "Canvas selection and pan" [ref=e62]:
        - generic:
          - iframe [ref=e63]:
            - generic [ref=f3e4]:
              - generic [ref=f3e6]: The Story in Numbers
              - generic [ref=f3e8]: Renewables grew 28% this year
              - generic [ref=f3e10]: Coal at its lowest share since 1965
          - img
      - generic [ref=e64]:
        - generic [ref=e65]: Select artwork or a timeline layer
        - generic [ref=e66]: "Arrows: move · Ctrl/Cmd+Arrows: resize · Shift: 10 px · Escape: cancel · Space: play/pause or drag to pan"
    - complementary "Inspector" [ref=e67]:
      - tablist "Inspector view" [ref=e68]:
        - tab "Properties" [selected] [ref=e69] [cursor=pointer]
        - tab "Outline" [ref=e70] [cursor=pointer]
      - generic [ref=e71]:
        - heading "Graphic" [level=2] [ref=e72]
        - generic [ref=e73]:
          - term [ref=e74]: Size
          - definition [ref=e75]: 1920 × 1080
          - term [ref=e76]: Frame rate
          - definition [ref=e77]: 25 fps
          - term [ref=e78]: Layers
          - definition [ref=e79]: "7"
          - term [ref=e80]: Motion
          - definition [ref=e81]: Source timeline
        - paragraph [ref=e82]: Select artwork on the canvas or a layer below to inspect it.
  - region "Timeline" [ref=e83]:
    - generic [ref=e84]:
      - strong [ref=e85]: Layers & Timeline
      - generic "Layer organization" [ref=e86]:
        - button "New layer folder" [ref=e87] [cursor=pointer]: + Folder
        - combobox "Move to layer folder" [disabled] [ref=e88] [cursor=pointer]:
          - option "Move to folder…" [selected]
          - option "Loose layers"
      - generic [ref=e89]:
        - generic [ref=e90]: 0 keys
        - combobox "Key ease" [disabled] [ref=e91] [cursor=pointer]:
          - option "Select keys" [selected]
          - option "Linear"
          - option "Easy Ease In"
          - option "Easy Ease Out"
          - option "Easy Ease"
          - option "Bounce"
          - option "Overshoot"
          - option "Hold"
      - button "Undo" [disabled] [ref=e92]
      - button "Redo" [disabled] [ref=e93]
      - generic [ref=e94]: 25 fps
    - generic [ref=e95]:
      - button "Go to beginning" [ref=e96] [cursor=pointer]: "|◀"
      - button "Previous frame" [ref=e97] [cursor=pointer]: ‹|
      - button "Play" [ref=e98] [cursor=pointer]: ▶ Play
      - button "Next frame" [ref=e99] [cursor=pointer]: "|›"
      - status [ref=e100]: 1.48 s
      - generic [ref=e101]: 37 frames
      - button "Add Step at playhead" [ref=e103] [cursor=pointer]
      - generic [ref=e104]:
        - button "Out" [ref=e105] [cursor=pointer]
        - button "Set Out at playhead" [ref=e106] [cursor=pointer]
        - button "Edit Out" [ref=e107] [cursor=pointer]
      - generic [ref=e108]:
        - text: Ruler
        - combobox "Ruler units" [ref=e109] [cursor=pointer]:
          - option "Seconds" [selected]
          - option "Frames"
    - generic [ref=e110]:
      - generic [ref=e111]:
        - generic [ref=e112]: Layers
        - generic [ref=e113]:
          - slider "Playhead" [ref=e114]:
            - generic [ref=e115]: 0.00 s
            - generic [ref=e116]: 0.50 s
            - generic [ref=e117]: 1.00 s
            - generic [ref=e118]: 1.50 s
            - generic [ref=e119]: 2.00 s
            - generic [ref=e120]: 2.50 s
            - generic [ref=e121]: In
          - button "Out flag" [ref=e122]: Out · hold
      - generic [ref=e124]:
        - generic [ref=e125]:
          - button "Properties of Whole graphic" [ref=e126] [cursor=pointer]: ▸
          - button "Hide Whole graphic layer" [pressed] [ref=e127] [cursor=pointer]:
            - img [ref=e128]
          - button "01 ◇ Whole graphic" [ref=e131] [cursor=pointer]:
            - generic [ref=e132]: "01"
            - generic [ref=e133]: ◇
            - generic [ref=e134]: Whole graphic
        - generic [ref=e135]:
          - button "Move Whole graphic span" [ref=e136]: Whole graphic
          - button "Trim start Whole graphic span" [ref=e137]
          - button "Trim end Whole graphic span" [ref=e138]
          - button "Move Whole graphic span" [ref=e139]: Whole graphic
          - button "Trim start Whole graphic span" [ref=e140]
          - button "Trim end Whole graphic span" [ref=e141]
      - generic [ref=e143]:
        - generic [ref=e144]:
          - button "Properties of Accent line" [ref=e145] [cursor=pointer]: ▸
          - button "Hide Accent line layer" [pressed] [ref=e146] [cursor=pointer]:
            - img [ref=e147]
          - button "02 ◇ Accent line" [ref=e150] [cursor=pointer]:
            - generic [ref=e151]: "02"
            - generic [ref=e152]: ◇
            - generic [ref=e153]: Accent line
        - generic [ref=e154]:
          - button "Move Accent line span" [ref=e155]: Accent line
          - button "Trim start Accent line span" [ref=e156]
          - button "Trim end Accent line span" [ref=e157]
          - button "Move Accent line span" [ref=e158]: Accent line
          - button "Trim start Accent line span" [ref=e159]
          - button "Trim end Accent line span" [ref=e160]
          - 'button "Accent line: Scale X key at 0.00 s" [ref=e161]': ◆
          - 'button "Accent line: Scale X key at 0.60 s" [ref=e162]': ◆
          - 'button "Accent line: Scale X key at 1.83 s" [ref=e163]': ◆
          - 'button "Accent line: Scale X key at 2.13 s" [ref=e164]': ◆
      - generic [ref=e166]:
        - generic [ref=e167]:
          - button "Properties of Panel" [ref=e168] [cursor=pointer]: ▸
          - button "Hide Panel layer" [pressed] [ref=e169] [cursor=pointer]:
            - img [ref=e170]
          - button "03 ◇ Panel" [ref=e173] [cursor=pointer]:
            - generic [ref=e174]: "03"
            - generic [ref=e175]: ◇
            - generic [ref=e176]: Panel
        - generic [ref=e177]:
          - button "Move Panel span" [ref=e178]: Panel
          - button "Trim start Panel span" [ref=e179]
          - button "Trim end Panel span" [ref=e180]
          - button "Move Panel span" [ref=e181]: Panel
          - button "Trim start Panel span" [ref=e182]
          - button "Trim end Panel span" [ref=e183]
          - 'button "Panel: clipPath, Opacity keys at 0.25 s" [ref=e184]': ◆
          - 'button "Panel: clipPath, Opacity keys at 0.90 s" [ref=e185]': ◆
          - 'button "Panel: clipPath, Opacity keys at 1.98 s" [ref=e186]': ◆
          - 'button "Panel: clipPath, Opacity keys at 2.28 s" [ref=e187]': ◆
      - generic [ref=e189]:
        - generic [ref=e190]:
          - button "Properties of Logo" [ref=e191] [cursor=pointer]: ▸
          - button "Hide Logo layer" [pressed] [ref=e192] [cursor=pointer]:
            - img [ref=e193]
          - button "04 ▧ Logo" [ref=e196] [cursor=pointer]:
            - generic [ref=e197]: "04"
            - generic [ref=e198]: ▧
            - generic [ref=e199]: Logo
        - generic [ref=e200]:
          - button "Move Logo span" [ref=e201]: Logo
          - button "Trim start Logo span" [ref=e202]
          - button "Trim end Logo span" [ref=e203]
          - button "Move Logo span" [ref=e204]: Logo
          - button "Trim start Logo span" [ref=e205]
          - button "Trim end Logo span" [ref=e206]
      - generic [ref=e208]:
        - generic [ref=e209]:
          - button "Properties of Heading" [ref=e210] [cursor=pointer]: ▸
          - button "Hide Heading layer" [pressed] [ref=e211] [cursor=pointer]:
            - img [ref=e212]
          - button "05 T Heading" [ref=e215] [cursor=pointer]:
            - generic [ref=e216]: "05"
            - generic [ref=e217]: T
            - generic [ref=e218]: Heading
        - generic [ref=e219]:
          - button "Move Heading span" [ref=e220]: Heading
          - button "Trim start Heading span" [ref=e221]
          - button "Trim end Heading span" [ref=e222]
          - button "Move Heading span" [ref=e223]: Heading
          - button "Trim start Heading span" [ref=e224]
          - button "Trim end Heading span" [ref=e225]
          - 'button "Heading: Y % key at 0.50 s" [ref=e226]': ◆
          - 'button "Heading: Y % key at 1.20 s" [ref=e227]': ◆
          - 'button "Heading: Y % key at 1.48 s" [ref=e228]': ◆
          - 'button "Heading: Y % key at 1.83 s" [ref=e229]': ◆
      - generic [ref=e231]:
        - generic [ref=e232]:
          - button "Properties of Line 1" [ref=e233] [cursor=pointer]: ▸
          - button "Hide Line 1 layer" [pressed] [ref=e234] [cursor=pointer]:
            - img [ref=e235]
          - button "06 T Line 1" [ref=e238] [cursor=pointer]:
            - generic [ref=e239]: "06"
            - generic [ref=e240]: T
            - generic [ref=e241]: Line 1
        - generic [ref=e242]:
          - button "Move Line 1 span" [ref=e243]: Line 1
          - button "Trim start Line 1 span" [ref=e244]
          - button "Trim end Line 1 span" [ref=e245]
          - button "Move Line 1 span" [ref=e246]: Line 1
          - button "Trim start Line 1 span" [ref=e247]
          - button "Trim end Line 1 span" [ref=e248]
          - 'button "Line 1: Y % key at 0.64 s" [ref=e249]': ◆
          - 'button "Line 1: Y % key at 1.34 s" [ref=e250]': ◆
          - 'button "Line 1: Y % key at 1.53 s" [ref=e251]': ◆
          - 'button "Line 1: Y % key at 1.88 s" [ref=e252]': ◆
      - generic [ref=e254]:
        - generic [ref=e255]:
          - button "Properties of Line 2" [ref=e256] [cursor=pointer]: ▸
          - button "Hide Line 2 layer" [pressed] [ref=e257] [cursor=pointer]:
            - img [ref=e258]
          - button "07 T Line 2" [ref=e261] [cursor=pointer]:
            - generic [ref=e262]: "07"
            - generic [ref=e263]: T
            - generic [ref=e264]: Line 2
        - generic [ref=e265]:
          - button "Move Line 2 span" [ref=e266]: Line 2
          - button "Trim start Line 2 span" [ref=e267]
          - button "Trim end Line 2 span" [ref=e268]
          - button "Move Line 2 span" [ref=e269]: Line 2
          - button "Trim start Line 2 span" [ref=e270]
          - button "Trim end Line 2 span" [ref=e271]
          - 'button "Line 2: Y % key at 0.78 s" [ref=e272]': ◆
          - 'button "Line 2: Y % key at 1.48 s" [ref=e273]': ◆
          - 'button "Line 2: Y % key at 1.58 s" [ref=e274]': ◆
          - 'button "Line 2: Y % key at 1.93 s" [ref=e275]': ◆
    - generic [ref=e276]:
      - generic [ref=e277]: "Space: play/pause · Arrows: frame · Escape: cancel"
      - generic [ref=e278]: "Body: move keys · Edges: trim visibility · Key: drag or arrows to move · Alt: bypass snap · Drag empty lane: select keys · Right-click key: ease · Flag: drag, double-click to rename"
  - generic [ref=e279]:
    - generic [ref=e280]: Artwork editing · Alpha
    - generic [ref=e281]: "Stopwatch: animate · Diamond: key at playhead"
```

# Test source

```ts
  503 |   const manifest: Record<string, unknown> = { sourceCanonicalSha256: createHash('sha256').update(JSON.stringify(prepared.source)).digest('hex'), sourceFileSha256: createHash('sha256').update(JSON.stringify(prepared.source, null, 2) + '\n').digest('hex'),
  504 |     fixture, operator: { data: fixture.operatorHeading, states: [1, 2, 'off', 1], entrances: 2, paintedNext: operatorNext }, packages: [], browserOnly: true };
  505 |   writeFileSync(info.outputPath('source.json'), JSON.stringify(prepared.source, null, 2) + '\n');
  506 |   const gsap = readFileSync('src/assets/gsap.min.js');
  507 |   for (const output of prepared.outputs) {
  508 |     const bytes = Buffer.from(output.base64, 'base64');
  509 |     writeFileSync(info.outputPath(`${output.id}.zip`), bytes);
  510 |     const zip = await JSZip.loadAsync(bytes), files = Object.keys(zip.files).filter(name => !zip.files[name].dir).sort();
  511 |     const fonts = files.filter(name => /\.woff2$/.test(name));
  512 |     if (output.id === 'spx' || output.id === 'ograf') {
  513 |       expect(fonts.length).toBeGreaterThan(0); expect(files.some(name => name.endsWith('/images/harbour.svg'))).toBe(true);
  514 |       const runtime = files.find(name => name.endsWith('/gsap.min.js'))!;
  515 |       expect(await zip.file(runtime)!.async('nodebuffer')).toEqual(gsap);
  516 |     }
  517 |     const root = files[0].split('/')[0], main = `${root}/${root}.html`;
  518 |     let runtimeReceipt: unknown = null;
  519 |     if (output.id === 'casparcg' || output.id === 'spx' || output.id === 'html-overlay') {
  520 |       const receiver = await context.newPage();
  521 |       await receiver.setViewportSize({ width: fixture.expected.resolution[0], height: fixture.expected.resolution[1] });
  522 |       await receiver.bringToFront();
  523 |       const missing: string[] = [];
  524 |       await receiver.route('http://e4-receiver.invalid/**', async route => {
  525 |         const file = decodeURIComponent(new URL(route.request().url()).pathname.slice(1));
  526 |         // A standalone static receiver intentionally has no optional local relay.
  527 |         if (file === 'relay/ping') { await route.fulfill({ status: 404, body: '' }); return; }
  528 |         if (!zip.file(file)) { missing.push(file); await route.fulfill({ status: 404, body: '' }); return; }
  529 |         const type = file.endsWith('.js') ? 'text/javascript' : file.endsWith('.css') ? 'text/css' : file.endsWith('.svg') ? 'image/svg+xml' : file.endsWith('.woff2') ? 'font/woff2' : 'text/html';
  530 |         await route.fulfill({ contentType: type, body: await zip.file(file)!.async('nodebuffer') });
  531 |       });
  532 |       try {
  533 |         await receiver.goto(`http://e4-receiver.invalid/${main}`);
  534 |         await receiver.evaluate(async heading => {
  535 |           await document.fonts.ready;
  536 |           const w = window as unknown as { update(data: string): void; play(): void };
  537 |           w.update(JSON.stringify({ f0: heading })); w.play();
  538 |         }, fixture.heading);
  539 |         await expect(receiver.locator('#f0')).toHaveText(fixture.heading);
  540 |         await expect.poll(() => receiver.evaluate(() => (window as unknown as { noacgStepsPlayed: number }).noacgStepsPlayed)).toBe(1);
  541 |         await expect(receiver.locator('.info-card')).toHaveCSS('opacity', '1');
  542 |         await expect.poll(() => receiver.locator('img').first().evaluate(img => (img as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);
  543 |         const assets = await receiver.evaluate(() => ({ font: getComputedStyle(document.querySelector('#f0')!).fontFamily,
  544 |           logo: [...document.images].find(img => img.src.includes('harbour') || img.src.startsWith('data:image/svg+xml'))?.naturalWidth ?? 0,
  545 |           rect: (() => { const r = document.querySelector('#f0')!.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height }; })() }));
  546 |         expect(assets.font).toContain('Oswald'); expect(assets.logo).toBe(fixture.expected.logoNaturalWidth);
  547 |         await receiver.evaluate(() => (window as unknown as { next(): void }).next());
  548 |         await expect.poll(() => receiver.evaluate(() => (window as unknown as { noacgStepsPlayed: number }).noacgStepsPlayed)).toBe(2);
  549 |         await expect(receiver.locator('.info-card-box')).toHaveCSS('opacity', '1');
  550 |         await expect(receiver.locator('.info-card-box')).toHaveCSS('clip-path', 'inset(0px 0% 0px 0px)');
  551 |         const paintedNext = await paintedNextRow(receiver.locator('#f1'), info.outputPath(`${output.id}-next-row.png`));
  552 |         await receiver.evaluate(() => (window as unknown as { stop(): void }).stop());
  553 |         await expect.poll(() => receiver.evaluate(() => (window as unknown as { noacgMachineState(): { groups: { main: string } } }).noacgMachineState().groups.main)).toBe('off');
  554 |         await expect(receiver.locator('.info-card')).toHaveCSS('opacity', '0');
  555 |         await receiver.evaluate(() => (window as unknown as { play(): void }).play());
  556 |         await expect.poll(() => receiver.evaluate(() => (window as unknown as { noacgStepsPlayed: number }).noacgStepsPlayed)).toBe(1);
  557 |         await expect(receiver.locator('.info-card')).toHaveCSS('opacity', '1');
  558 |         await expect(receiver.locator('.info-card-box')).toHaveCSS('opacity', '1');
  559 |         await expect(receiver.locator('.info-card-box')).toHaveCSS('clip-path', 'inset(0px 0% 0px 0px)');
  560 |         await expect(receiver.locator('#f0')).toBeVisible();
  561 |         await expect(receiver.locator('#f0')).toHaveCSS('transform', 'matrix(1, 0, 0, 1, 0, 0)');
  562 |         await expect(receiver.locator('#f0')).toHaveText(fixture.heading);
  563 |         await expect.poll(() => receiver.locator('img').first().evaluate(img => (img as HTMLImageElement).naturalWidth)).toBe(fixture.expected.logoNaturalWidth);
  564 |         // Existing capture contract: fence composited paint only AFTER visible output settles.
  565 |         const paint = await receiver.addStyleTag({ content: '* { will-change: auto !important; }' });
  566 |         await receiver.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  567 |         await paint.evaluate(el => el.remove());
  568 |         await receiver.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  569 |         writeFileSync(info.outputPath(`${output.id}-paint-state.json`), JSON.stringify(await receiver.evaluate(() => ({ viewport: { width: innerWidth, height: innerHeight }, visibility: document.visibilityState,
  570 |           nodes: ['html', 'body', '.info-card', '.info-card-box', '.info-card-accent', '#f0', '#f5'].map(selector => { const el = document.querySelector(selector)!, css = getComputedStyle(el), rect = el.getBoundingClientRect();
  571 |             return { selector, rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }, opacity: css.opacity, visibility: css.visibility, display: css.display, transform: css.transform, clip: css.clipPath, color: css.color, background: css.backgroundColor }; }) })), null, 2));
  572 |         const paintedFrame = decodePng(await receiver.screenshot({ path: info.outputPath(`${output.id}-replay.png`) }));
  573 |         expect([paintedFrame.width, paintedFrame.height]).toEqual(fixture.expected.resolution);
  574 |         const painted = findPixelsNear(paintedFrame, [22, 187, 153], 0);
  575 |         expect(painted.count, 'the receiving frame paints the authored green artwork').toBeGreaterThan(0);
  576 |         expect(missing.filter(path => !path.endsWith('favicon.ico'))).toEqual([]);
  577 |         runtimeReceipt = { optionalRelay: '404; standalone static server', data: fixture.heading, states: [1, 2, 'off', 1], assets, missing, painted, paintedNext };
  578 |       } finally { await receiver.close(); }
  579 |     } else {
  580 |       expect(files.some(name => name.endsWith('.ograf.json'))).toBe(true);
  581 |     }
  582 |     (manifest.packages as unknown[]).push({ target: output.id, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'), files, runtime: runtimeReceipt });
  583 |   }
  584 |   writeFileSync(info.outputPath('receiving-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  585 | });
  586 | 
  587 | 
  588 | for (const door of ['api', 'document', 'brand', 'save', 'create'] as const) test(`external draft is durably retained through project ${door}`, async ({ page }) => {
  589 |   const ids = await seedAuthoringProject(page);
  590 |   const external = await page.evaluate(async () => {
  591 |     const S = (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore;
  592 |     const s = S.getState(); s.applyTemplate({ ...s.template, name: 'External harbour draft' }, { resetSampleData: true });
  593 |     const look = (await __noacgImport('/src/model/packets.ts')).createLook('Batch brand', { styleTag: 'minimal', fontId: 'inter', customFont: null,
  594 |       palette: { id: 'custom', name: 'Harbour', styleTags: ['minimal'], accent: '#16bb99', text: '#ffffff', textDim: '#aaaabb', panel: '#112233' } });
  595 |     return { id: S.getState().documentId, look: look.id };
  596 |   });
  597 |   await editProjectText(page, 'External source must survive');
  598 |   await flushAuthoringProject(page);
  599 |   const before = await page.evaluate(async () => {
  600 |     const s = (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore.getState();
  601 |     return { template: s.template, history: s.history, saved: { graphicId: s.saved.graphicId, dirty: s.saved.dirty } };
  602 |   });
> 603 |   if (door === 'api' || door === 'create') await page.evaluate(async ({ id, door }) => {
      |                                                       ^ Error: page.evaluate: Execution context was destroyed, most likely because of a navigation.
  604 |     const P = await __noacgImport('/src/store/authoringProjects.ts');
  605 |     const ok = door === 'api' ? await P.openProjectDocument(id) : await P.createAuthoringProject('Second project', [P.workspace().documents[0].template]);
  606 |     if (!ok) throw new Error(P.useAuthoringProjects.getState().error);
  607 |   }, { id: ids[1], door });
  608 |   else {
  609 |     await page.getByRole('button', { name: /^Project/ }).first().click();
  610 |     if (door === 'document') await page.locator(`[data-document="${ids[1]}"]`).click();
  611 |     else {
  612 |       await page.locator(`[data-document="${ids[1]}"]`).locator('..').getByRole('checkbox').check();
  613 |       if (door === 'brand') { await page.getByLabel('Brand for selected graphics').selectOption(external.look); await page.getByRole('button', { name: 'Apply brand', exact: true }).click(); }
  614 |       else await page.getByRole('button', { name: 'Save selected', exact: true }).click();
  615 |       await expect(page.getByTestId('project-note')).toContainText(door === 'brand' ? 'Brand applied' : 'graphics saved');
  616 |       expect(await page.evaluate(async () => (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore.getState().documentId)).toBe(external.id);
  617 |     }
  618 |   }
  619 |   await flushAuthoringProject(page);
  620 |   const kept = await page.evaluate(async id => (await __noacgImport('/src/store/authoringProjects.ts')).workspace().documents.find(d => d.id === id), external.id);
  621 |   expect(kept).toBeDefined(); expect(kept!.template).toEqual(before.template); expect(kept!.history).toEqual(before.history); expect(kept!.saved).toEqual(before.saved);
  622 |   await page.reload(); await expect(page.getByTestId('editor-foundation')).toBeVisible();
  623 |   const reopened = await page.evaluate(async id => {
  624 |     const P = await __noacgImport('/src/store/authoringProjects.ts');
  625 |     if (!await P.openProjectDocument(id)) throw new Error(P.useAuthoringProjects.getState().error);
  626 |     const s = (await __noacgImport('/src/components/editorFoundation/documentAdapter.ts')).activeEditorSession();
  627 |     const draft = s.port.read(); s.undo(); const undo = s.port.read(); s.redo();
  628 |     return { draft, undo, redo: s.port.read() };
  629 |   }, external.id);
  630 |   expect(reopened.draft).toEqual(before.template); expect(reopened.undo.html).not.toContain('External source must survive'); expect(reopened.redo).toEqual(before.template);
  631 | });
  632 | 
  633 | test('refused external retention and cancelled Home/starter switches keep the unfiled working source', async ({ page }) => {
  634 |   await armStorageFailure(page);
  635 |   const ids = await seedAuthoringProject(page);
  636 |   const externalId = await page.evaluate(async () => {
  637 |     const s = (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore.getState();
  638 |     s.applyTemplate({ ...s.template, name: 'External refusal' }, { resetSampleData: true });
  639 |     return (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore.getState().documentId;
  640 |   });
  641 |   await editProjectText(page, 'Refused external must stay open'); await flushAuthoringProject(page);
  642 |   await fillStorage(page);
  643 |   const result = await page.evaluate(async id => {
  644 |     const P = await __noacgImport('/src/store/authoringProjects.ts'); const ok = await P.openProjectDocument(id);
  645 |     const s = (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore.getState();
  646 |     return { ok, id: s.documentId, html: s.template.html };
  647 |   }, ids[0]);
  648 |   expect(result.ok).toBe(false); expect(result.id).toBe(externalId); expect(result.html).toContain('Refused external must stay open');
  649 |   await freeStorage(page);
  650 |   await page.getByTestId('open-home').click();
  651 |   await expect(page.getByTestId('confirm-switch')).toBeVisible();
  652 |   await page.getByTestId('switch-cancel').click();
  653 |   await expect(page.getByTestId('editor-foundation')).toBeVisible();
  654 |   expect(await page.evaluate(async () => (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore.getState().documentId)).toBe(externalId);
  655 |   await page.getByRole('button', { name: /^Project/ }).first().click();
  656 |   await page.getByRole('button', { name: 'New project', exact: true }).click();
  657 |   await expect(page.getByTestId('project-starter')).toBeVisible();
  658 |   await page.getByTestId('project-starter').getByRole('button', { name: /^Create project/ }).click();
  659 |   await expect(page.getByTestId('confirm-switch')).toBeVisible();
  660 |   await page.getByTestId('switch-cancel').click();
  661 |   const cancelled = await page.evaluate(async () => {
  662 |     const s = (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore.getState();
  663 |     return { id: s.documentId, html: s.template.html, projects: (await __noacgImport('/src/store/authoringProjects.ts')).workspace().projects.length };
  664 |   });
  665 |   expect(cancelled.id).toBe(externalId); expect(cancelled.html).toContain('Refused external must stay open'); expect(cancelled.projects).toBe(1);
  666 |   await page.getByRole('button', { name: 'Close new project', exact: true }).click();
  667 | });
  668 | 
  669 | test('library Save As and same-private-id baseline changes retire old ports before binding refresh', async ({ page }) => {
  670 |   await seedAuthoringProject(page);
  671 |   const result = await page.evaluate(async () => {
  672 |     const S = (await __noacgImport('/src/store/templateStore.ts')).useTemplateStore;
  673 |     const D = await __noacgImport('/src/components/editorFoundation/documentAdapter.ts');
  674 |     const A = await __noacgImport('/src/store/saveActions.ts');
  675 |     const s = S.getState(); s.applyTemplate({ ...s.template, name: 'External ownership' }, { resetSampleData: true });
  676 |     const privateId = S.getState().documentId, initial = D.activeEditorSession();
  677 |     const closed = (port: typeof initial.port) => { try { port.restore({ selectedParts: [], time: 99 }); return ''; } catch (e) { return String(e); } };
  678 |     const first = await A.saveGraphicAs('Ownership first', { kind: 'standalone' });
  679 |     if (!first.ok) throw new Error(first.error!);
  680 |     const initialClosed = closed(initial.port), firstSession = D.activeEditorSession();
  681 |     const firstOwner = { public: firstSession.documentId, instance: firstSession.instanceId, private: S.getState().documentId, graphic: S.getState().saved.graphicId };
  682 |     const second = await A.saveGraphicAs('Ownership second', { kind: 'standalone' });
  683 |     if (!second.ok) throw new Error(second.error!);
  684 |     const firstClosed = closed(firstSession.port), secondSession = D.activeEditorSession();
  685 |     const secondOwner = { public: secondSession.documentId, instance: secondSession.instanceId, private: S.getState().documentId, graphic: S.getState().saved.graphicId };
  686 |     const source = secondSession.port.read();
  687 |     S.setState({ baseline: structuredClone(S.getState().baseline) });
  688 |     const baselineClosed = closed(secondSession.port); // No call to activeEditorSession yet.
  689 |     const refreshed = D.activeEditorSession();
  690 |     const baselineOwner = { public: refreshed.documentId, instance: refreshed.instanceId, private: S.getState().documentId, graphic: S.getState().saved.graphicId };
  691 |     return { privateId, initialClosed, firstClosed, baselineClosed, first: first.graphicId, second: second.graphicId,
  692 |       firstOwner, secondOwner, baselineOwner, sourceKept: JSON.stringify(refreshed.port.read()) === JSON.stringify(source) };
  693 |   });
  694 |   for (const closed of [result.initialClosed, result.firstClosed, result.baselineClosed]) expect(closed).toContain('closed');
  695 |   expect(result.firstOwner.public).toBe(result.first); expect(result.secondOwner.public).toBe(result.second); expect(result.first).not.toBe(result.second);
  696 |   expect(result.firstOwner.private).toBe(result.privateId); expect(result.secondOwner.private).toBe(result.privateId); expect(result.baselineOwner.private).toBe(result.privateId);
  697 |   expect(result.firstOwner.instance).not.toBe(result.secondOwner.instance); expect(result.secondOwner.instance).not.toBe(result.baselineOwner.instance);
  698 |   expect(result.baselineOwner.public).toBe(result.second); expect(result.baselineOwner.graphic).toBe(result.second); expect(result.sourceKept).toBe(true);
  699 | });
  700 | 
  701 | test('two retained drafts sharing a saved library link keep distinct public workspace ownership', async ({ page }) => {
  702 |   const ids = await seedAuthoringProject(page);
  703 |   const result = await page.evaluate(async firstId => {
```