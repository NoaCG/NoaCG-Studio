from pathlib import Path
import hashlib,json,subprocess,re,time
root=Path.cwd();out=root/'e5f.local/blank-source-mutation';out.mkdir(exist_ok=True)
helper=root/'src/components/editorFoundation/startBlankGraphic.ts';factory=root/'src/templates/blank.ts'
good=helper.read_bytes();goodFactory=factory.read_bytes()
c=json.loads((root/'e5f.local/blank-implementation-checkpoint.json').read_text())
oldHelper=good.decode().replace('    const save = useSaveUi.getState();\n    if (save.confirmSwitch || save.saveDialog) return false;\n    const request = current.current;','    const request = current.current;',1).encode()
oldFactory=(goodFactory.decode().split('/** Empty placed artwork')[0].replace("import { IMPORTED_DESIGN, PREFIX } from './importedDesign/shared';", "import { neutralSpineFor } from './types/neutralDesign';")+'''/** The visual editor's blank uses the existing authorable source/runtime spine. */
export function createAuthoringBlankTemplate(res: Resolution = DEFAULT_GRAPHICS_RESOLUTION, fps = DEFAULT_GRAPHICS_FORMAT.fps): SpxTemplate {
  return neutralSpineFor([], { name: 'Untitled graphic', lines: [], resolution: res, fps });
}
''').encode()
assert hashlib.sha256(oldHelper).hexdigest()==c['paths']['src/components/editorFoundation/startBlankGraphic.ts']
assert hashlib.sha256(oldFactory).hexdigest()==c['paths']['src/templates/blank.ts']
for name,data in [('good-helper.ts',good),('good-factory.ts',goodFactory),('failed-shared-helper.ts',oldHelper),('failed-neutral-factory.ts',oldFactory)]: (out/name).write_bytes(data)
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':{str(out/name):hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ['good-helper.ts','good-factory.ts','failed-shared-helper.ts','failed-neutral-factory.ts']},'specSha256':hashlib.sha256((root/'e2e/editor-projects.spec.ts').read_bytes()).hexdigest(),'restored':False}
receipt=out/'receipt.json';receipt.write_text(json.dumps(record,indent=2)+'\n')
condition='      if (!owns(request) || !latest.current.open || latest.current.walk !== request.walk || useRouter.getState().route !== request.route) return;\n'
bad=good.decode().replace('    if (save.confirmSwitch || save.saveDialog) return false;\n','',1).replace(condition,'',1).encode()
assert bad!=good and condition.encode() not in bad
record['mutantSha256']=hashlib.sha256(bad).hexdigest();receipt.write_text(json.dumps(record,indent=2)+'\n')
try:
 helper.write_bytes(bad)
 command="NOACG_E2E_ON_BUILD=0 NOACG_E2E_EXPECTED_SPECS=editor-projects.spec.ts npm run test:e2e -- e2e/editor-projects.spec.ts --project=chromium --workers=2 --grep 'requested blank escape keeps|held Save cannot revive' --output=e5f.local/blank-guard-mutant"
 result=subprocess.run(['node','scripts/jobs.mjs','add',command,'--cap','5'],text=True,capture_output=True)
 (out/'enqueue.log').write_text(result.stdout+result.stderr)
 assert result.returncode==0,result.stderr
 job=re.search(r'j-\d+',result.stdout).group();record['job']=job;receipt.write_text(json.dumps(record,indent=2)+'\n')
 status=Path('/workspace/NoaCG-Studio/.git/noacg-jobs')/(job+'.json')
 while True:
  state=json.loads(status.read_text())
  if state['state'] not in ['waiting','running']:break
  time.sleep(1)
 record['terminal']=state
 (out/(job+'.log')).write_bytes(Path(state['logPath']).read_bytes())
finally:
 helper.write_bytes((out/'good-helper.ts').read_bytes())
 record['restored']=helper.read_bytes()==good
 record['restoredSha256']=hashlib.sha256(helper.read_bytes()).hexdigest()
 receipt.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2),flush=True)
 assert record['restored']
