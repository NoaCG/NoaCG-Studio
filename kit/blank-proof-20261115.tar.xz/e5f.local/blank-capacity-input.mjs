import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { gateReport, gateFile } from '../scripts/growth-report.mjs';
const listingFile = 'e5f.local/growth-artifacts-page1.json';
const priorFile = '/workspace/noacg-editor-r1-5-e5f-quiz-edit/e5f.local/quiz-round2-growth.json';
const priorLog = '/workspace/noacg-editor-r1-5-e5f-quiz-edit/e5f.local/quiz-growth-fetch.log';
const listing = JSON.parse(readFileSync(listingFile, 'utf8'));
const prior = JSON.parse(readFileSync(priorFile, 'utf8'));
if (listing.total_count !== 7 || listing.artifacts.length !== 7 || listing.artifacts.some(a => a.created_at > '2026-11-14T21:58:00Z')) throw Error('The retained artifact-failure scope changed.');
const failures = readFileSync(priorLog, 'utf8').split('\n').filter(l => l.startsWith('error downloading growth-report:') && l.endsWith('Forbidden')).length;
if (failures !== 7 || !prior.none || !prior.gate.newest.readFailed) throw Error('Missing original seven transport refusals.');
const replayed = [];
const gh = args => {
  if (args[0] === 'api' && args.at(-1) === 'repos/NoaCG/NoaCG-Studio/actions/artifacts?name=growth-report&per_page=100&page=1') return JSON.stringify(listing);
  if (args[0] === 'run' && args[1] === 'download' && listing.artifacts.some(a => String(a.workflow_run.id) === args[2])) {
    replayed.push(args[2]);
    throw Error('Reused retained artifact Forbidden evidence; no new download executed.');
  }
  throw Error('Unexpected canonical capacity input request: ' + args.slice(0, 3).join(' '));
};
const ceilings = JSON.parse(readFileSync('scripts/growth-ceilings.json', 'utf8'));
const picked = gateReport({ gh, ceilings });
gateFile('e5f.local/blank-final-growth.json', picked);
const current = JSON.parse(readFileSync('e5f.local/blank-final-growth.json', 'utf8'));
if (JSON.stringify(current) !== JSON.stringify(prior)) throw Error('Reused canonical report result changed.');
const hash = f => createHash('sha256').update(readFileSync(f)).digest('hex');
writeFileSync('e5f.local/blank-capacity-input-receipt.json', JSON.stringify({ head: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  currentCompleteArtifactListing: { file: listingFile, sha256: hash(listingFile), count: 7 },
  reusedPrior: { file: priorFile, sha256: hash(priorFile), failedDownloadLogSha256: hash(priorLog), failures },
  canonicalGateFile: 'e5f.local/blank-final-growth.json', canonicalSha256: hash('e5f.local/blank-final-growth.json'),
  logicalDownloadReadsReusingOldFailures: replayed, newCliOrDownloadInvocations: 0, judgedOn: current.gate.judgedOn, newest: current.gate.newest }, null, 2) + '\n');
console.log('Canonical gateReport/gateFile: unchanged report readFailed; frozen seed. Current complete7/7 listing + retained seven Forbidden downloads, no retries.');
